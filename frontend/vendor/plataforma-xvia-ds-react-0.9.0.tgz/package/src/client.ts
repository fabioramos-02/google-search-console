/**
 * GERADO por scripts/generate-wrappers.mjs a partir de @plataforma-xvia/ds-core/dist/docs.json — componentes client (SSR-compatíveis, ADR-008).
 * Não edite: corrija o componente Stencil ou o gerador.
 */

/* eslint-disable */
import type { Components } from "@plataforma-xvia/ds-core/dist/components";
import type { DsAccordionToggleDetail, DsActionDetail, DsCalendarNavigateDetail, DsCalendarSelectDetail, DsCheckboxChangeDetail, DsCodeInputChangeDetail, DsComboboxChangeDetail, DsContextSelectDetail, DsDrawerToggleDetail, DsFeedbackDetail, DsFileDropChangeDetail, DsFileDropRemoveDetail, DsInputChangeDetail, DsMultiSelectChangeDetail, DsNumberInputChangeDetail, DsPageChangeDetail, DsRadioChangeDetail, DsRangeChangeDetail, DsSegmentChangeDetail, DsSelectChangeDetail, DsSelectionChangeDetail, DsSortDetail, DsSplitSelectDetail, DsSwitchChangeDetail, DsTabChangeDetail, DsTagRemoveDetail, DsTagToggleDetail, DsToggleDetail } from "@plataforma-xvia/ds-core";
import { defineCustomElement as defineDsAccessibilityBar } from "@plataforma-xvia/ds-core/dist/components/ds-accessibility-bar.js";
import { defineCustomElement as defineDsAccordion } from "@plataforma-xvia/ds-core/dist/components/ds-accordion.js";
import { defineCustomElement as defineDsAccordionItem } from "@plataforma-xvia/ds-core/dist/components/ds-accordion-item.js";
import { defineCustomElement as defineDsAccountPanel } from "@plataforma-xvia/ds-core/dist/components/ds-account-panel.js";
import { defineCustomElement as defineDsAlert } from "@plataforma-xvia/ds-core/dist/components/ds-alert.js";
import { defineCustomElement as defineDsAnnouncementBar } from "@plataforma-xvia/ds-core/dist/components/ds-announcement-bar.js";
import { defineCustomElement as defineDsAppBar } from "@plataforma-xvia/ds-core/dist/components/ds-app-bar.js";
import { defineCustomElement as defineDsAppGrid } from "@plataforma-xvia/ds-core/dist/components/ds-app-grid.js";
import { defineCustomElement as defineDsAvatar } from "@plataforma-xvia/ds-core/dist/components/ds-avatar.js";
import { defineCustomElement as defineDsBadge } from "@plataforma-xvia/ds-core/dist/components/ds-badge.js";
import { defineCustomElement as defineDsBlockCard } from "@plataforma-xvia/ds-core/dist/components/ds-block-card.js";
import { defineCustomElement as defineDsBreadcrumb } from "@plataforma-xvia/ds-core/dist/components/ds-breadcrumb.js";
import { defineCustomElement as defineDsButton } from "@plataforma-xvia/ds-core/dist/components/ds-button.js";
import { defineCustomElement as defineDsButtonGroup } from "@plataforma-xvia/ds-core/dist/components/ds-button-group.js";
import { defineCustomElement as defineDsCalendar } from "@plataforma-xvia/ds-core/dist/components/ds-calendar.js";
import { defineCustomElement as defineDsCard } from "@plataforma-xvia/ds-core/dist/components/ds-card.js";
import { defineCustomElement as defineDsCarousel } from "@plataforma-xvia/ds-core/dist/components/ds-carousel.js";
import { defineCustomElement as defineDsChart } from "@plataforma-xvia/ds-core/dist/components/ds-chart.js";
import { defineCustomElement as defineDsCheckbox } from "@plataforma-xvia/ds-core/dist/components/ds-checkbox.js";
import { defineCustomElement as defineDsCodeInput } from "@plataforma-xvia/ds-core/dist/components/ds-code-input.js";
import { defineCustomElement as defineDsCombobox } from "@plataforma-xvia/ds-core/dist/components/ds-combobox.js";
import { defineCustomElement as defineDsContactList } from "@plataforma-xvia/ds-core/dist/components/ds-contact-list.js";
import { defineCustomElement as defineDsContextMenu } from "@plataforma-xvia/ds-core/dist/components/ds-context-menu.js";
import { defineCustomElement as defineDsCookieBanner } from "@plataforma-xvia/ds-core/dist/components/ds-cookie-banner.js";
import { defineCustomElement as defineDsDivider } from "@plataforma-xvia/ds-core/dist/components/ds-divider.js";
import { defineCustomElement as defineDsDrawer } from "@plataforma-xvia/ds-core/dist/components/ds-drawer.js";
import { defineCustomElement as defineDsEmptyState } from "@plataforma-xvia/ds-core/dist/components/ds-empty-state.js";
import { defineCustomElement as defineDsEntryList } from "@plataforma-xvia/ds-core/dist/components/ds-entry-list.js";
import { defineCustomElement as defineDsFeedback } from "@plataforma-xvia/ds-core/dist/components/ds-feedback.js";
import { defineCustomElement as defineDsFileCard } from "@plataforma-xvia/ds-core/dist/components/ds-file-card.js";
import { defineCustomElement as defineDsFileDrop } from "@plataforma-xvia/ds-core/dist/components/ds-file-drop.js";
import { defineCustomElement as defineDsFilterGroup } from "@plataforma-xvia/ds-core/dist/components/ds-filter-group.js";
import { defineCustomElement as defineDsFootActions } from "@plataforma-xvia/ds-core/dist/components/ds-foot-actions.js";
import { defineCustomElement as defineDsFooter } from "@plataforma-xvia/ds-core/dist/components/ds-footer.js";
import { defineCustomElement as defineDsHeader } from "@plataforma-xvia/ds-core/dist/components/ds-header.js";
import { defineCustomElement as defineDsIcon } from "@plataforma-xvia/ds-core/dist/components/ds-icon.js";
import { defineCustomElement as defineDsImage } from "@plataforma-xvia/ds-core/dist/components/ds-image.js";
import { defineCustomElement as defineDsInfoSystem } from "@plataforma-xvia/ds-core/dist/components/ds-info-system.js";
import { defineCustomElement as defineDsInput } from "@plataforma-xvia/ds-core/dist/components/ds-input.js";
import { defineCustomElement as defineDsKbd } from "@plataforma-xvia/ds-core/dist/components/ds-kbd.js";
import { defineCustomElement as defineDsKpi } from "@plataforma-xvia/ds-core/dist/components/ds-kpi.js";
import { defineCustomElement as defineDsLink } from "@plataforma-xvia/ds-core/dist/components/ds-link.js";
import { defineCustomElement as defineDsLinkCard } from "@plataforma-xvia/ds-core/dist/components/ds-link-card.js";
import { defineCustomElement as defineDsLinkItem } from "@plataforma-xvia/ds-core/dist/components/ds-link-item.js";
import { defineCustomElement as defineDsList } from "@plataforma-xvia/ds-core/dist/components/ds-list.js";
import { defineCustomElement as defineDsMediaCard } from "@plataforma-xvia/ds-core/dist/components/ds-media-card.js";
import { defineCustomElement as defineDsMenu } from "@plataforma-xvia/ds-core/dist/components/ds-menu.js";
import { defineCustomElement as defineDsMultiSelect } from "@plataforma-xvia/ds-core/dist/components/ds-multi-select.js";
import { defineCustomElement as defineDsNavbar } from "@plataforma-xvia/ds-core/dist/components/ds-navbar.js";
import { defineCustomElement as defineDsNewsCard } from "@plataforma-xvia/ds-core/dist/components/ds-news-card.js";
import { defineCustomElement as defineDsNumberInput } from "@plataforma-xvia/ds-core/dist/components/ds-number-input.js";
import { defineCustomElement as defineDsPageHeader } from "@plataforma-xvia/ds-core/dist/components/ds-page-header.js";
import { defineCustomElement as defineDsPagination } from "@plataforma-xvia/ds-core/dist/components/ds-pagination.js";
import { defineCustomElement as defineDsPlayer } from "@plataforma-xvia/ds-core/dist/components/ds-player.js";
import { defineCustomElement as defineDsQuote } from "@plataforma-xvia/ds-core/dist/components/ds-quote.js";
import { defineCustomElement as defineDsRadio } from "@plataforma-xvia/ds-core/dist/components/ds-radio.js";
import { defineCustomElement as defineDsRange } from "@plataforma-xvia/ds-core/dist/components/ds-range.js";
import { defineCustomElement as defineDsRating } from "@plataforma-xvia/ds-core/dist/components/ds-rating.js";
import { defineCustomElement as defineDsSearch } from "@plataforma-xvia/ds-core/dist/components/ds-search.js";
import { defineCustomElement as defineDsSectionHeading } from "@plataforma-xvia/ds-core/dist/components/ds-section-heading.js";
import { defineCustomElement as defineDsSegmentButton } from "@plataforma-xvia/ds-core/dist/components/ds-segment-button.js";
import { defineCustomElement as defineDsSelect } from "@plataforma-xvia/ds-core/dist/components/ds-select.js";
import { defineCustomElement as defineDsServiceCard } from "@plataforma-xvia/ds-core/dist/components/ds-service-card.js";
import { defineCustomElement as defineDsSheet } from "@plataforma-xvia/ds-core/dist/components/ds-sheet.js";
import { defineCustomElement as defineDsShortcutCard } from "@plataforma-xvia/ds-core/dist/components/ds-shortcut-card.js";
import { defineCustomElement as defineDsSocialCard } from "@plataforma-xvia/ds-core/dist/components/ds-social-card.js";
import { defineCustomElement as defineDsSplitButton } from "@plataforma-xvia/ds-core/dist/components/ds-split-button.js";
import { defineCustomElement as defineDsStat } from "@plataforma-xvia/ds-core/dist/components/ds-stat.js";
import { defineCustomElement as defineDsStatus } from "@plataforma-xvia/ds-core/dist/components/ds-status.js";
import { defineCustomElement as defineDsStepper } from "@plataforma-xvia/ds-core/dist/components/ds-stepper.js";
import { defineCustomElement as defineDsSteps } from "@plataforma-xvia/ds-core/dist/components/ds-steps.js";
import { defineCustomElement as defineDsSummary } from "@plataforma-xvia/ds-core/dist/components/ds-summary.js";
import { defineCustomElement as defineDsSummaryCard } from "@plataforma-xvia/ds-core/dist/components/ds-summary-card.js";
import { defineCustomElement as defineDsSwitch } from "@plataforma-xvia/ds-core/dist/components/ds-switch.js";
import { defineCustomElement as defineDsTab } from "@plataforma-xvia/ds-core/dist/components/ds-tab.js";
import { defineCustomElement as defineDsTable } from "@plataforma-xvia/ds-core/dist/components/ds-table.js";
import { defineCustomElement as defineDsTabs } from "@plataforma-xvia/ds-core/dist/components/ds-tabs.js";
import { defineCustomElement as defineDsTag } from "@plataforma-xvia/ds-core/dist/components/ds-tag.js";
import { defineCustomElement as defineDsTextarea } from "@plataforma-xvia/ds-core/dist/components/ds-textarea.js";
import { defineCustomElement as defineDsTile } from "@plataforma-xvia/ds-core/dist/components/ds-tile.js";
import { defineCustomElement as defineDsToast } from "@plataforma-xvia/ds-core/dist/components/ds-toast.js";
import { defineCustomElement as defineDsToaster } from "@plataforma-xvia/ds-core/dist/components/ds-toaster.js";
import { defineCustomElement as defineDsToggle } from "@plataforma-xvia/ds-core/dist/components/ds-toggle.js";
import { defineCustomElement as defineDsTooltip } from "@plataforma-xvia/ds-core/dist/components/ds-tooltip.js";
import { defineCustomElement as defineDsTopbar } from "@plataforma-xvia/ds-core/dist/components/ds-topbar.js";
import { createDsClientComponent } from "./runtime/client";

export type { DsClientComponent, DsClientComponentOptions, DsClientProps } from "./runtime/client";

export type DsAccessibilityBarEvents = {};
export type DsAccessibilityBarProps = Partial<Components.DsAccessibilityBar>;
/** `<ds-accessibility-bar>` em React (client). Barra de acessibilidade do topo (referência ms.gov.br): atalhos "Ir para */
export const DsAccessibilityBar = /* @__PURE__ */ createDsClientComponent<HTMLDsAccessibilityBarElement, Components.DsAccessibilityBar, DsAccessibilityBarEvents>({ tagName: "ds-accessibility-bar", attributes: { "label": "label", "links": "links" }, events: {  }, defineCustomElement: defineDsAccessibilityBar, displayName: "DsAccessibilityBar" });

export type DsAccordionEvents = {};
export type DsAccordionProps = Partial<Components.DsAccordion>;
/** `<ds-accordion>` em React (client). Agrupa `ds-accordion-item`s: navegação por setas/Home/End entre os gatilhos */
export const DsAccordion = /* @__PURE__ */ createDsClientComponent<HTMLDsAccordionElement, Components.DsAccordion, DsAccordionEvents>({ tagName: "ds-accordion", attributes: { "exclusive": "exclusive", "separated": "separated", "variant": "variant" }, events: {  }, defineCustomElement: defineDsAccordion, displayName: "DsAccordion" });

export type DsAccordionItemEvents = {
  readonly onDsToggle?: (event: CustomEvent<DsAccordionToggleDetail>) => void;
};
export type DsAccordionItemProps = Partial<Components.DsAccordionItem>;
/** `<ds-accordion-item>` em React (client). Item de acordeão sobre `<details>/<summary>` nativos: o conteúdo é legível, */
export const DsAccordionItem = /* @__PURE__ */ createDsClientComponent<HTMLDsAccordionItemElement, Components.DsAccordionItem, DsAccordionItemEvents>({ tagName: "ds-accordion-item", attributes: { "disabled": "disabled", "heading": "heading", "headingLevel": "heading-level", "headingTone": "heading-tone", "nested": "nested", "open": "open", "standalone": "standalone" }, events: { onDsToggle: "dsToggle" }, defineCustomElement: defineDsAccordionItem, displayName: "DsAccordionItem" });

export type DsAccountPanelEvents = {};
export type DsAccountPanelProps = Partial<Components.DsAccountPanel>;
/** `<ds-account-panel>` em React (client). Painel lateral da área logada (kit "Menu Lateral"): foto ou iniciais, nome, */
export const DsAccountPanel = /* @__PURE__ */ createDsClientComponent<HTMLDsAccountPanelElement, Components.DsAccountPanel, DsAccountPanelEvents>({ tagName: "ds-account-panel", attributes: { "attached": "attached", "backHref": "back-href", "backLabel": "back-label", "items": "items", "itemsHeading": "items-heading", "label": "label", "name": "name", "profileHref": "profile-href", "profileLabel": "profile-label", "src": "src" }, events: {  }, defineCustomElement: defineDsAccountPanel, displayName: "DsAccountPanel" });

export type DsAlertEvents = {
  readonly onDsDismiss?: (event: CustomEvent<unknown>) => void;
};
export type DsAlertProps = Partial<Components.DsAlert>;
/** `<ds-alert>` em React (client). Aviso em caixa (kit: Alert): fundo tintado, borda e filete à esquerda no tom, */
export const DsAlert = /* @__PURE__ */ createDsClientComponent<HTMLDsAlertElement, Components.DsAlert, DsAlertEvents>({ tagName: "ds-alert", attributes: { "closeLabel": "close-label", "dismissible": "dismissible", "heading": "heading", "icon": "icon", "tone": "tone" }, events: { onDsDismiss: "dsDismiss" }, defineCustomElement: defineDsAlert, displayName: "DsAlert" });

export type DsAnnouncementBarEvents = {
  readonly onDsDismiss?: (event: CustomEvent<unknown>) => void;
};
export type DsAnnouncementBarProps = Partial<Components.DsAnnouncementBar>;
/** `<ds-announcement-bar>` em React (client). Faixa de anúncio no topo da página (kit: Top_banner_fixer): fundo */
export const DsAnnouncementBar = /* @__PURE__ */ createDsClientComponent<HTMLDsAnnouncementBarElement, Components.DsAnnouncementBar, DsAnnouncementBarEvents>({ tagName: "ds-announcement-bar", attributes: { "closeLabel": "close-label", "ctaLabel": "cta-label", "dismissible": "dismissible", "href": "href", "icon": "icon", "label": "label" }, events: { onDsDismiss: "dsDismiss" }, defineCustomElement: defineDsAnnouncementBar, displayName: "DsAnnouncementBar" });

export type DsAppBarEvents = {};
export type DsAppBarProps = Partial<Components.DsAppBar>;
/** `<ds-app-bar>` em React (client). Barra superior de um sistema da área administrativa (kit: Navbar / System). */
export const DsAppBar = /* @__PURE__ */ createDsClientComponent<HTMLDsAppBarElement, Components.DsAppBar, DsAppBarEvents>({ tagName: "ds-app-bar", attributes: { "appsHref": "apps-href", "appsLabel": "apps-label", "autoCurrent": "auto-current", "brand": "brand", "closeLabel": "close-label", "homeHref": "home-href", "homeLabel": "home-label", "items": "items", "label": "label", "menuLabel": "menu-label", "notificationsCount": "notifications-count", "notificationsHref": "notifications-href", "notificationsLabel": "notifications-label", "searchAction": "search-action", "searchId": "search-id", "searchLabel": "search-label", "searchName": "search-name", "searchPlaceholder": "search-placeholder", "userHref": "user-href", "userImage": "user-image", "userName": "user-name", "variant": "variant" }, events: {  }, defineCustomElement: defineDsAppBar, displayName: "DsAppBar" });

export type DsAppGridEvents = {};
export type DsAppGridProps = Partial<Components.DsAppGrid>;
/** `<ds-app-grid>` em React (client). Grade de atalhos de aplicativos (kit: Menu / Apps): três por linha, cada um */
export const DsAppGrid = /* @__PURE__ */ createDsClientComponent<HTMLDsAppGridElement, Components.DsAppGrid, DsAppGridEvents>({ tagName: "ds-app-grid", attributes: { "allHref": "all-href", "allLabel": "all-label", "columns": "columns", "items": "items", "label": "label" }, events: {  }, defineCustomElement: defineDsAppGrid, displayName: "DsAppGrid" });

export type DsAvatarEvents = {};
export type DsAvatarProps = Partial<Components.DsAvatar>;
/** `<ds-avatar>` em React (client). Avatar do kit: círculo com a foto (`src`); sem foto, as iniciais (`initials` */
export const DsAvatar = /* @__PURE__ */ createDsClientComponent<HTMLDsAvatarElement, Components.DsAvatar, DsAvatarEvents>({ tagName: "ds-avatar", attributes: { "alt": "alt", "initials": "initials", "name": "name", "size": "size", "src": "src", "status": "status", "statusLabel": "status-label" }, events: {  }, defineCustomElement: defineDsAvatar, displayName: "DsAvatar" });

export type DsBadgeEvents = {};
export type DsBadgeProps = Partial<Components.DsBadge>;
/** `<ds-badge>` em React (client). Etiqueta tonal para categoria, situação ou modalidade. Conteúdo puro (zero JS). */
export const DsBadge = /* @__PURE__ */ createDsClientComponent<HTMLDsBadgeElement, Components.DsBadge, DsBadgeEvents>({ tagName: "ds-badge", attributes: { "icon": "icon", "size": "size", "tone": "tone" }, events: {  }, defineCustomElement: defineDsBadge, displayName: "DsBadge" });

export type DsBlockCardEvents = {};
export type DsBlockCardProps = Partial<Components.DsBlockCard>;
/** `<ds-block-card>` em React (client). Card de bloco (kit Card/Block): logotipo redondo à esquerda, título em azul, */
export const DsBlockCard = /* @__PURE__ */ createDsClientComponent<HTMLDsBlockCardElement, Components.DsBlockCard, DsBlockCardEvents>({ tagName: "ds-block-card", attributes: { "ctaLabel": "cta-label", "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt" }, events: {  }, defineCustomElement: defineDsBlockCard, displayName: "DsBlockCard" });

export type DsBreadcrumbEvents = {};
export type DsBreadcrumbProps = Partial<Components.DsBreadcrumb>;
/** `<ds-breadcrumb>` em React (client). Trilha de navegação. Conteúdo puro (zero JS): renderiza `nav > ol > li > a` */
export const DsBreadcrumb = /* @__PURE__ */ createDsClientComponent<HTMLDsBreadcrumbElement, Components.DsBreadcrumb, DsBreadcrumbEvents>({ tagName: "ds-breadcrumb", attributes: { "backHref": "back-href", "backLabel": "back-label", "homeIcon": "home-icon", "items": "items", "label": "label" }, events: {  }, defineCustomElement: defineDsBreadcrumb, displayName: "DsBreadcrumb" });

export type DsButtonEvents = {};
export type DsButtonProps = Partial<Components.DsButton>;
/** `<ds-button>` em React (client). Botão do DS. Renderiza um `<button>` nativo ou, com `href`, um `<a>` — sempre */
export const DsButton = /* @__PURE__ */ createDsClientComponent<HTMLDsButtonElement, Components.DsButton, DsButtonEvents>({ tagName: "ds-button", attributes: { "appearance": "appearance", "disabled": "disabled", "download": "download", "fullWidth": "full-width", "href": "href", "icon": "icon", "iconPosition": "icon-position", "label": "label", "loading": "loading", "rel": "rel", "shape": "shape", "size": "size", "target": "target", "tone": "tone", "type": "type", "variant": "variant" }, events: {  }, defineCustomElement: defineDsButton, displayName: "DsButton" });

export type DsButtonGroupEvents = {};
export type DsButtonGroupProps = Partial<Components.DsButtonGroup>;
/** `<ds-button-group>` em React (client). Contêiner de botões (kit: página Actions). Só layout: CSS e slots, nada de */
export const DsButtonGroup = /* @__PURE__ */ createDsClientComponent<HTMLDsButtonGroupElement, Components.DsButtonGroup, DsButtonGroupEvents>({ tagName: "ds-button-group", attributes: { "align": "align", "gap": "gap", "label": "label", "stack": "stack", "wrap": "wrap" }, events: {  }, defineCustomElement: defineDsButtonGroup, displayName: "DsButtonGroup" });

export type DsCalendarEvents = {
  readonly onDsNavigate?: (event: CustomEvent<DsCalendarNavigateDetail>) => void;
  readonly onDsSelect?: (event: CustomEvent<DsCalendarSelectDetail>) => void;
};
export type DsCalendarProps = Partial<Components.DsCalendar>;
/** `<ds-calendar>` em React (client). Calendário mensal (kit: Calendar). Uma `<table>` com `<caption>` do mês, */
export const DsCalendar = /* @__PURE__ */ createDsClientComponent<HTMLDsCalendarElement, Components.DsCalendar, DsCalendarEvents>({ tagName: "ds-calendar", attributes: { "dayHrefTemplate": "day-href-template", "events": "events", "label": "label", "maxEvents": "max-events", "month": "month", "nextHref": "next-href", "nextLabel": "next-label", "prevHref": "prev-href", "prevLabel": "prev-label", "rangeEnd": "range-end", "rangeStart": "range-start", "today": "today", "todayHref": "today-href", "todayLabel": "today-label", "value": "value", "variant": "variant" }, events: { onDsNavigate: "dsNavigate", onDsSelect: "dsSelect" }, defineCustomElement: defineDsCalendar, displayName: "DsCalendar" });

export type DsCardEvents = {};
export type DsCardProps = Partial<Components.DsCard>;
/** `<ds-card>` em React (client). Superfície de card. Conteúdo puro (zero JS). Com `heading`, o card vira uma */
export const DsCard = /* @__PURE__ */ createDsClientComponent<HTMLDsCardElement, Components.DsCard, DsCardEvents>({ tagName: "ds-card", attributes: { "brandHeader": "brand-header", "description": "description", "flush": "flush", "heading": "heading", "headingId": "heading-id", "headingLevel": "heading-level", "icon": "icon", "interactive": "interactive", "muted": "muted", "tone": "tone" }, events: {  }, defineCustomElement: defineDsCard, displayName: "DsCard" });

export type DsCarouselEvents = {};
export type DsCarouselProps = Partial<Components.DsCarousel>;
/** `<ds-carousel>` em React (client). Trilha horizontal com rolagem por snap (banners, atalhos). O conteúdo é HTML */
export const DsCarousel = /* @__PURE__ */ createDsClientComponent<HTMLDsCarouselElement, Components.DsCarousel, DsCarouselEvents>({ tagName: "ds-carousel", attributes: { "dotLabel": "dot-label", "dots": "dots", "itemWidth": "item-width", "label": "label", "narrowOnly": "narrow-only", "nextLabel": "next-label", "prevLabel": "prev-label", "wideOnly": "wide-only" }, events: {  }, defineCustomElement: defineDsCarousel, displayName: "DsCarousel" });

export type DsChartEvents = {};
export type DsChartProps = Partial<Components.DsChart>;
/** `<ds-chart>` em React (client). Gráfico de linhas ou barras da área administrativa (Chart do kit), em SVG */
export const DsChart = /* @__PURE__ */ createDsClientComponent<HTMLDsChartElement, Components.DsChart, DsChartEvents>({ tagName: "ds-chart", attributes: { "chartId": "chart-id", "decimals": "decimals", "emptyText": "empty-text", "heading": "heading", "height": "height", "labels": "labels", "markers": "markers", "series": "series", "type": "type" }, events: {  }, defineCustomElement: defineDsChart, displayName: "DsChart" });

export type DsCheckboxEvents = {
  readonly onDsChange?: (event: CustomEvent<DsCheckboxChangeDetail>) => void;
};
export type DsCheckboxProps = Partial<Components.DsCheckbox>;
/** `<ds-checkbox>` em React (client). Caixa de seleção nativa estilizada. O `<input>` é real e fica no formulário */
export const DsCheckbox = /* @__PURE__ */ createDsClientComponent<HTMLDsCheckboxElement, Components.DsCheckbox, DsCheckboxEvents>({ tagName: "ds-checkbox", attributes: { "checked": "checked", "description": "description", "disabled": "disabled", "icon": "icon", "image": "image", "imageAlt": "image-alt", "inputId": "input-id", "label": "label", "name": "name", "value": "value", "variant": "variant" }, events: { onDsChange: "dsChange" }, defineCustomElement: defineDsCheckbox, displayName: "DsCheckbox" });

export type DsCodeInputEvents = {
  readonly onDsChange?: (event: CustomEvent<DsCodeInputChangeDetail>) => void;
};
export type DsCodeInputProps = Partial<Components.DsCodeInput>;
/** `<ds-code-input>` em React (client). Código de verificação (kit ".input[2.0] / OPT"): N caixas quadradas, uma por */
export const DsCodeInput = /* @__PURE__ */ createDsClientComponent<HTMLDsCodeInputElement, Components.DsCodeInput, DsCodeInputEvents>({ tagName: "ds-code-input", attributes: { "alphanumeric": "alphanumeric", "disabled": "disabled", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "length": "length", "name": "name", "status": "status", "value": "value" }, events: { onDsChange: "dsChange" }, defineCustomElement: defineDsCodeInput, displayName: "DsCodeInput" });

export type DsComboboxEvents = {
  readonly onDsComboboxChange?: (event: CustomEvent<DsComboboxChangeDetail>) => void;
  readonly onDsFooterAction?: (event: CustomEvent<unknown>) => void;
};
export type DsComboboxProps = Partial<Components.DsCombobox>;
/** `<ds-combobox>` em React (client). Campo que filtra digitando e escolhe numa lista (referência: "Filtrar */
export const DsCombobox = /* @__PURE__ */ createDsClientComponent<HTMLDsComboboxElement, Components.DsCombobox, DsComboboxEvents>({ tagName: "ds-combobox", attributes: { "disabled": "disabled", "emptyText": "empty-text", "footerActionLabel": "footer-action-label", "fullWidth": "full-width", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "value": "value" }, events: { onDsComboboxChange: "dsComboboxChange", onDsFooterAction: "dsFooterAction" }, defineCustomElement: defineDsCombobox, displayName: "DsCombobox" });

export type DsContactListEvents = {};
export type DsContactListProps = Partial<Components.DsContactList>;
/** `<ds-contact-list>` em React (client). Lista de pessoas (kit Card/InfoPersonList): avatar com iniciais (ou foto), nome em */
export const DsContactList = /* @__PURE__ */ createDsClientComponent<HTMLDsContactListElement, Components.DsContactList, DsContactListEvents>({ tagName: "ds-contact-list", attributes: { "emptyText": "empty-text", "items": "items", "label": "label", "moreLabel": "more-label" }, events: {  }, defineCustomElement: defineDsContactList, displayName: "DsContactList" });

export type DsContextMenuEvents = {
  readonly onDsSelect?: (event: CustomEvent<DsContextSelectDetail>) => void;
};
export type DsContextMenuProps = Partial<Components.DsContextMenu>;
/** `<ds-context-menu>` em React (client). Menu de ações (kit "ContextMenu"): caixa branca com sombra que abre a partir */
export const DsContextMenu = /* @__PURE__ */ createDsClientComponent<HTMLDsContextMenuElement, Components.DsContextMenu, DsContextMenuEvents>({ tagName: "ds-context-menu", attributes: { "items": "items", "label": "label", "open": "open" }, events: { onDsSelect: "dsSelect" }, defineCustomElement: defineDsContextMenu, displayName: "DsContextMenu" });

export type DsCookieBannerEvents = {
  readonly onDsAccept?: (event: CustomEvent<unknown>) => void;
  readonly onDsSettings?: (event: CustomEvent<unknown>) => void;
};
export type DsCookieBannerProps = Partial<Components.DsCookieBanner>;
/** `<ds-cookie-banner>` em React (client). Faixa de cookies (kit: cookie_banner, LGPD): fundo institucional, ícone de */
export const DsCookieBanner = /* @__PURE__ */ createDsClientComponent<HTMLDsCookieBannerElement, Components.DsCookieBanner, DsCookieBannerEvents>({ tagName: "ds-cookie-banner", attributes: { "acceptHref": "accept-href", "acceptLabel": "accept-label", "formAction": "form-action", "label": "label", "name": "name", "settingsHref": "settings-href", "settingsLabel": "settings-label", "static": "static", "value": "value" }, events: { onDsAccept: "dsAccept", onDsSettings: "dsSettings" }, defineCustomElement: defineDsCookieBanner, displayName: "DsCookieBanner" });

export type DsDividerEvents = {};
export type DsDividerProps = Partial<Components.DsDivider>;
/** `<ds-divider>` em React (client). Filete separador do kit ("divider"): `<hr>` puro ou, com `label`, um separador */
export const DsDivider = /* @__PURE__ */ createDsClientComponent<HTMLDsDividerElement, Components.DsDivider, DsDividerEvents>({ tagName: "ds-divider", attributes: { "dashed": "dashed", "label": "label", "orientation": "orientation" }, events: {  }, defineCustomElement: defineDsDivider, displayName: "DsDivider" });

export type DsDrawerEvents = {
  readonly onDsToggle?: (event: CustomEvent<DsDrawerToggleDetail>) => void;
};
export type DsDrawerProps = Partial<Components.DsDrawer>;
/** `<ds-drawer>` em React (client). Menu lateral da área administrativa (kit: página Menu, "Navbar"). Duas */
export const DsDrawer = /* @__PURE__ */ createDsClientComponent<HTMLDsDrawerElement, Components.DsDrawer, DsDrawerEvents>({ tagName: "ds-drawer", attributes: { "autoCurrent": "auto-current", "collapsed": "collapsed", "helpHref": "help-href", "helpLabel": "help-label", "homeHref": "home-href", "homeLabel": "home-label", "items": "items", "label": "label", "logoutHref": "logout-href", "logoutLabel": "logout-label", "toggleLabel": "toggle-label", "userHref": "user-href", "userImage": "user-image", "userName": "user-name", "workspace": "workspace", "workspaceHref": "workspace-href", "workspaceLabel": "workspace-label" }, events: { onDsToggle: "dsToggle" }, defineCustomElement: defineDsDrawer, displayName: "DsDrawer" });

export type DsEmptyStateEvents = {};
export type DsEmptyStateProps = Partial<Components.DsEmptyState>;
/** `<ds-empty-state>` em React (client). Estado vazio (kit: Empty State): ícone grande, título em negrito, texto */
export const DsEmptyState = /* @__PURE__ */ createDsClientComponent<HTMLDsEmptyStateElement, Components.DsEmptyState, DsEmptyStateEvents>({ tagName: "ds-empty-state", attributes: { "compact": "compact", "description": "description", "heading": "heading", "headingLevel": "heading-level", "icon": "icon" }, events: {  }, defineCustomElement: defineDsEmptyState, displayName: "DsEmptyState" });

export type DsEntryListEvents = {};
export type DsEntryListProps = Partial<Components.DsEntryList>;
/** `<ds-entry-list>` em React (client). Lista de resultados em linhas (referência: catálogo de serviços): sobretítulo em */
export const DsEntryList = /* @__PURE__ */ createDsClientComponent<HTMLDsEntryListElement, Components.DsEntryList, DsEntryListEvents>({ tagName: "ds-entry-list", attributes: { "emptyText": "empty-text", "items": "items", "label": "label" }, events: {  }, defineCustomElement: defineDsEntryList, displayName: "DsEntryList" });

export type DsFeedbackEvents = {
  readonly onDsFeedback?: (event: CustomEvent<DsFeedbackDetail>) => void;
};
export type DsFeedbackProps = Partial<Components.DsFeedback>;
/** `<ds-feedback>` em React (client). "Esta informação foi útil para você?" — sim/não em formulário nativo (`POST` */
export const DsFeedback = /* @__PURE__ */ createDsClientComponent<HTMLDsFeedbackElement, Components.DsFeedback, DsFeedbackEvents>({ tagName: "ds-feedback", attributes: { "action": "action", "errorHeading": "error-heading", "errorHref": "error-href", "errorLabel": "error-label", "errorText": "error-text", "name": "name", "noLabel": "no-label", "question": "question", "selected": "selected", "thanksText": "thanks-text", "yesLabel": "yes-label" }, events: { onDsFeedback: "dsFeedback" }, defineCustomElement: defineDsFeedback, displayName: "DsFeedback" });

export type DsFileCardEvents = {};
export type DsFileCardProps = Partial<Components.DsFileCard>;
/** `<ds-file-card>` em React (client). Card de arquivo (kit Card/Files): quadrado cinza com o ícone e o tipo (PDF, DOC…) */
export const DsFileCard = /* @__PURE__ */ createDsClientComponent<HTMLDsFileCardElement, Components.DsFileCard, DsFileCardEvents>({ tagName: "ds-file-card", attributes: { "date": "date", "downloadHref": "download-href", "downloadLabel": "download-label", "heading": "heading", "headingLevel": "heading-level", "href": "href", "kind": "kind", "previewHref": "preview-href", "previewLabel": "preview-label", "size": "size" }, events: {  }, defineCustomElement: defineDsFileCard, displayName: "DsFileCard" });

export type DsFileDropEvents = {
  readonly onDsChange?: (event: CustomEvent<DsFileDropChangeDetail>) => void;
  readonly onDsRemove?: (event: CustomEvent<DsFileDropRemoveDetail>) => void;
};
export type DsFileDropProps = Partial<Components.DsFileDrop>;
/** `<ds-file-drop>` em React (client). Área de envio de arquivos (kit "Input / File[2.0]"): `<input type="file">` */
export const DsFileDrop = /* @__PURE__ */ createDsClientComponent<HTMLDsFileDropElement, Components.DsFileDrop, DsFileDropEvents>({ tagName: "ds-file-drop", attributes: { "accept": "accept", "disabled": "disabled", "files": "files", "hint": "hint", "inputId": "input-id", "label": "label", "maxSize": "max-size", "multiple": "multiple", "name": "name", "prompt": "prompt", "removeLabel": "remove-label", "required": "required", "status": "status", "uploadingText": "uploading-text" }, events: { onDsChange: "dsChange", onDsRemove: "dsRemove" }, defineCustomElement: defineDsFileDrop, displayName: "DsFileDrop" });

export type DsFilterGroupEvents = {};
export type DsFilterGroupProps = Partial<Components.DsFilterGroup>;
/** `<ds-filter-group>` em React (client). Grupo de filtros recolhível (referência: "Categoria ▾", "Subcategoria ⓘ ▴"): */
export const DsFilterGroup = /* @__PURE__ */ createDsClientComponent<HTMLDsFilterGroupElement, Components.DsFilterGroup, DsFilterGroupEvents>({ tagName: "ds-filter-group", attributes: { "heading": "heading", "info": "info", "open": "open" }, events: {  }, defineCustomElement: defineDsFilterGroup, displayName: "DsFilterGroup" });

export type DsFootActionsEvents = {};
export type DsFootActionsProps = Partial<Components.DsFootActions>;
/** `<ds-foot-actions>` em React (client). Barra de ações do rodapé de um formulário (kit: FootActions). A aplicação põe */
export const DsFootActions = /* @__PURE__ */ createDsClientComponent<HTMLDsFootActionsElement, Components.DsFootActions, DsFootActionsEvents>({ tagName: "ds-foot-actions", attributes: { "align": "align", "autosaveText": "autosave-text", "label": "label", "position": "position" }, events: {  }, defineCustomElement: defineDsFootActions, displayName: "DsFootActions" });

export type DsFooterEvents = {};
export type DsFooterProps = Partial<Components.DsFooter>;
/** `<ds-footer>` em React (client). Rodapé institucional em três faixas (referência ms.gov.br): colunas de links */
export const DsFooter = /* @__PURE__ */ createDsClientComponent<HTMLDsFooterElement, Components.DsFooter, DsFooterEvents>({ tagName: "ds-footer", attributes: { "bottomLinks": "bottom-links", "collapsible": "collapsible", "collapsibleLabel": "collapsible-label", "columns": "columns", "variant": "variant" }, events: {  }, defineCustomElement: defineDsFooter, displayName: "DsFooter" });

export type DsHeaderEvents = {};
export type DsHeaderProps = Partial<Components.DsHeader>;
/** `<ds-header>` em React (client). Faixa institucional do topo (fundo da marca): logotipo à esquerda e ações à */
export const DsHeader = /* @__PURE__ */ createDsClientComponent<HTMLDsHeaderElement, Components.DsHeader, DsHeaderEvents>({ tagName: "ds-header", attributes: { "closeLabel": "close-label", "homeHref": "home-href", "homeLabel": "home-label", "menuLabel": "menu-label", "navItems": "nav-items", "navLabel": "nav-label", "secondaryItems": "secondary-items" }, events: {  }, defineCustomElement: defineDsHeader, displayName: "DsHeader" });

export type DsIconEvents = {};
export type DsIconProps = Partial<Components.DsIcon>;
/** `<ds-icon>` em React (client). Ícone do catálogo `@plataforma-xvia/ds-icons`. Decorativo por padrão */
export const DsIcon = /* @__PURE__ */ createDsClientComponent<HTMLDsIconElement, Components.DsIcon, DsIconEvents>({ tagName: "ds-icon", attributes: { "label": "label", "name": "name", "size": "size" }, events: {  }, defineCustomElement: defineDsIcon, displayName: "DsIcon" });

export type DsImageEvents = {};
export type DsImageProps = Partial<Components.DsImage>;
/** `<ds-image>` em React (client). Imagem com proporção fixa do kit ("Image" / "Aspect"): `<img>` dentro de uma */
export const DsImage = /* @__PURE__ */ createDsClientComponent<HTMLDsImageElement, Components.DsImage, DsImageEvents>({ tagName: "ds-image", attributes: { "alt": "alt", "caption": "caption", "fit": "fit", "height": "height", "loading": "loading", "ratio": "ratio", "rounded": "rounded", "sizes": "sizes", "src": "src", "srcset": "srcset", "width": "width" }, events: {  }, defineCustomElement: defineDsImage, displayName: "DsImage" });

export type DsInfoSystemEvents = {};
export type DsInfoSystemProps = Partial<Components.DsInfoSystem>;
/** `<ds-info-system>` em React (client). Linha discreta de informações técnicas do sistema (kit: InfoSystem), em */
export const DsInfoSystem = /* @__PURE__ */ createDsClientComponent<HTMLDsInfoSystemElement, Components.DsInfoSystem, DsInfoSystemEvents>({ tagName: "ds-info-system", attributes: { "align": "align", "environment": "environment", "ip": "ip", "items": "items", "label": "label", "published": "published", "publishedLabel": "published-label", "separator": "separator", "system": "system", "version": "version", "versionLabel": "version-label" }, events: {  }, defineCustomElement: defineDsInfoSystem, displayName: "DsInfoSystem" });

export type DsInputEvents = {
  readonly onDsChange?: (event: CustomEvent<DsInputChangeDetail>) => void;
  readonly onDsInput?: (event: CustomEvent<DsInputChangeDetail>) => void;
};
export type DsInputProps = Partial<Components.DsInput>;
/** `<ds-input>` em React (client). Campo de texto do kit (Textfield e Textfield 2.0, com Label e texto de ajuda). */
export const DsInput = /* @__PURE__ */ createDsClientComponent<HTMLDsInputElement, Components.DsInput, DsInputEvents>({ tagName: "ds-input", attributes: { "autocomplete": "autocomplete", "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "icon": "icon", "iconEnd": "icon-end", "inputId": "input-id", "inputmode": "inputmode", "label": "label", "labelPosition": "label-position", "max": "max", "maxlength": "maxlength", "min": "min", "name": "name", "pattern": "pattern", "placeholder": "placeholder", "readonly": "readonly", "required": "required", "size": "size", "status": "status", "step": "step", "type": "type", "value": "value" }, events: { onDsChange: "dsChange", onDsInput: "dsInput" }, defineCustomElement: defineDsInput, displayName: "DsInput" });

export type DsKbdEvents = {};
export type DsKbdProps = Partial<Components.DsKbd>;
/** `<ds-kbd>` em React (client). Atalho de teclado do kit ("Hotkey": "Ctrl+K"). Cada tecla vira um `<kbd>` */
export const DsKbd = /* @__PURE__ */ createDsClientComponent<HTMLDsKbdElement, Components.DsKbd, DsKbdEvents>({ tagName: "ds-kbd", attributes: { "keys": "keys" }, events: {  }, defineCustomElement: defineDsKbd, displayName: "DsKbd" });

export type DsKpiEvents = {};
export type DsKpiProps = Partial<Components.DsKpi>;
/** `<ds-kpi>` em React (client). KPI compacto de painel (Statistics do kit): card pequeno com ícone, rótulo */
export const DsKpi = /* @__PURE__ */ createDsClientComponent<HTMLDsKpiElement, Components.DsKpi, DsKpiEvents>({ tagName: "ds-kpi", attributes: { "appearance": "appearance", "help": "help", "icon": "icon", "label": "label", "progress": "progress", "progressLabel": "progress-label", "progressText": "progress-text", "size": "size", "tone": "tone", "value": "value" }, events: {  }, defineCustomElement: defineDsKpi, displayName: "DsKpi" });

export type DsLinkEvents = {};
export type DsLinkProps = Partial<Components.DsLink>;
/** `<ds-link>` em React (client). Link de texto da referência: tons (azul, amarelo, vermelho, neutro), sublinhado */
export const DsLink = /* @__PURE__ */ createDsClientComponent<HTMLDsLinkElement, Components.DsLink, DsLinkEvents>({ tagName: "ds-link", attributes: { "external": "external", "href": "href", "icon": "icon", "size": "size", "tone": "tone", "underline": "underline" }, events: {  }, defineCustomElement: defineDsLink, displayName: "DsLink" });

export type DsLinkCardEvents = {};
export type DsLinkCardProps = Partial<Components.DsLinkCard>;
/** `<ds-link-card>` em React (client). Card com título e lista de links ("Destaques", "Mais acessados"). Cada link */
export const DsLinkCard = /* @__PURE__ */ createDsClientComponent<HTMLDsLinkCardElement, Components.DsLinkCard, DsLinkCardEvents>({ tagName: "ds-link-card", attributes: { "emptyText": "empty-text", "heading": "heading", "headingLevel": "heading-level", "icon": "icon", "items": "items", "numbered": "numbered" }, events: {  }, defineCustomElement: defineDsLinkCard, displayName: "DsLinkCard" });

export type DsLinkItemEvents = {};
export type DsLinkItemProps = Partial<Components.DsLinkItem>;
/** `<ds-link-item>` em React (client). Card-linha de link (kit Card/Link): quadrado cinza com o ícone à esquerda, */
export const DsLinkItem = /* @__PURE__ */ createDsClientComponent<HTMLDsLinkItemElement, Components.DsLinkItem, DsLinkItemEvents>({ tagName: "ds-link-item", attributes: { "external": "external", "eyebrow": "eyebrow", "eyebrowPosition": "eyebrow-position", "heading": "heading", "headingLevel": "heading-level", "href": "href", "icon": "icon", "tinted": "tinted", "underline": "underline" }, events: {  }, defineCustomElement: defineDsLinkItem, displayName: "DsLinkItem" });

export type DsListEvents = {};
export type DsListProps = Partial<Components.DsList>;
/** `<ds-list>` em React (client). Lista de conteúdo do kit ("List"): `<ul>`/`<ol>` a partir de `items` (JSON). */
export const DsList = /* @__PURE__ */ createDsClientComponent<HTMLDsListElement, Components.DsList, DsListEvents>({ tagName: "ds-list", attributes: { "icon": "icon", "items": "items", "label": "label", "size": "size", "variant": "variant" }, events: {  }, defineCustomElement: defineDsList, displayName: "DsList" });

export type DsMediaCardEvents = {};
export type DsMediaCardProps = Partial<Components.DsMediaCard>;
/** `<ds-media-card>` em React (client). Card de imagem com texto sobreposto (kit: destaque de notícia): foto de fundo, */
export const DsMediaCard = /* @__PURE__ */ createDsClientComponent<HTMLDsMediaCardElement, Components.DsMediaCard, DsMediaCardEvents>({ tagName: "ds-media-card", attributes: { "category": "category", "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt", "ratio": "ratio" }, events: {  }, defineCustomElement: defineDsMediaCard, displayName: "DsMediaCard" });

export type DsMenuEvents = {};
export type DsMenuProps = Partial<Components.DsMenu>;
/** `<ds-menu>` em React (client). Lista de itens de menu com seta (referência "Item ›"). Conteúdo puro (zero JS). */
export const DsMenu = /* @__PURE__ */ createDsClientComponent<HTMLDsMenuElement, Components.DsMenu, DsMenuEvents>({ tagName: "ds-menu", attributes: { "items": "items", "label": "label" }, events: {  }, defineCustomElement: defineDsMenu, displayName: "DsMenu" });

export type DsMultiSelectEvents = {
  readonly onDsMultiSelectChange?: (event: CustomEvent<DsMultiSelectChangeDetail>) => void;
};
export type DsMultiSelectProps = Partial<Components.DsMultiSelect>;
/** `<ds-multi-select>` em React (client). Escolha múltipla por chips (referência: "Órgão" na coluna de filtros). Cada */
export const DsMultiSelect = /* @__PURE__ */ createDsClientComponent<HTMLDsMultiSelectElement, Components.DsMultiSelect, DsMultiSelectEvents>({ tagName: "ds-multi-select", attributes: { "chipsLabel": "chips-label", "disabled": "disabled", "emptyText": "empty-text", "fullWidth": "full-width", "hideLabel": "hide-label", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "removeLabel": "remove-label", "selectId": "select-id" }, events: { onDsMultiSelectChange: "dsMultiSelectChange" }, defineCustomElement: defineDsMultiSelect, displayName: "DsMultiSelect" });

export type DsNavbarEvents = {};
export type DsNavbarProps = Partial<Components.DsNavbar>;
/** `<ds-navbar>` em React (client). Barra de navegação principal (faixa branca sob o cabeçalho). Itens com */
export const DsNavbar = /* @__PURE__ */ createDsClientComponent<HTMLDsNavbarElement, Components.DsNavbar, DsNavbarEvents>({ tagName: "ds-navbar", attributes: { "autoCurrent": "auto-current", "items": "items", "label": "label", "narrowHidden": "narrow-hidden" }, events: {  }, defineCustomElement: defineDsNavbar, displayName: "DsNavbar" });

export type DsNewsCardEvents = {};
export type DsNewsCardProps = Partial<Components.DsNewsCard>;
/** `<ds-news-card>` em React (client). Card de notícia. Conteúdo puro: sem estado, sem eventos, sem JavaScript — */
export const DsNewsCard = /* @__PURE__ */ createDsClientComponent<HTMLDsNewsCardElement, Components.DsNewsCard, DsNewsCardEvents>({ tagName: "ds-news-card", attributes: { "category": "category", "ctaLabel": "cta-label", "date": "date", "excerpt": "excerpt", "external": "external", "headingLevel": "heading-level", "headline": "headline", "href": "href", "image": "image", "imageAlt": "image-alt", "orientation": "orientation", "tags": "tags" }, events: {  }, defineCustomElement: defineDsNewsCard, displayName: "DsNewsCard" });

export type DsNumberInputEvents = {
  readonly onDsChange?: (event: CustomEvent<DsNumberInputChangeDetail>) => void;
  readonly onDsInput?: (event: CustomEvent<DsNumberInputChangeDetail>) => void;
};
export type DsNumberInputProps = Partial<Components.DsNumberInput>;
/** `<ds-number-input>` em React (client). Campo numérico com botões `+`/`−` empilhados à direita (kit: campo "15" com */
export const DsNumberInput = /* @__PURE__ */ createDsClientComponent<HTMLDsNumberInputElement, Components.DsNumberInput, DsNumberInputEvents>({ tagName: "ds-number-input", attributes: { "appearance": "appearance", "decrementLabel": "decrement-label", "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "incrementLabel": "increment-label", "inputId": "input-id", "label": "label", "max": "max", "min": "min", "name": "name", "placeholder": "placeholder", "required": "required", "size": "size", "status": "status", "step": "step", "value": "value" }, events: { onDsChange: "dsChange", onDsInput: "dsInput" }, defineCustomElement: defineDsNumberInput, displayName: "DsNumberInput" });

export type DsPageHeaderEvents = {};
export type DsPageHeaderProps = Partial<Components.DsPageHeader>;
/** `<ds-page-header>` em React (client). Cabeçalho de página: trilha, título (h1), descrição, etiquetas e ações. */
export const DsPageHeader = /* @__PURE__ */ createDsClientComponent<HTMLDsPageHeaderElement, Components.DsPageHeader, DsPageHeaderEvents>({ tagName: "ds-page-header", attributes: { "description": "description", "eyebrow": "eyebrow", "heading": "heading", "headingLevel": "heading-level", "icon": "icon", "muted": "muted" }, events: {  }, defineCustomElement: defineDsPageHeader, displayName: "DsPageHeader" });

export type DsPaginationEvents = {
  readonly onDsPageChange?: (event: CustomEvent<DsPageChangeDetail>) => void;
};
export type DsPaginationProps = Partial<Components.DsPagination>;
/** `<ds-pagination>` em React (client). Paginação numerada (anterior, páginas com reticências, próxima; com `edges`, */
export const DsPagination = /* @__PURE__ */ createDsClientComponent<HTMLDsPaginationElement, Components.DsPagination, DsPaginationEvents>({ tagName: "ds-pagination", attributes: { "compactEdges": "compact-edges", "compactSiblings": "compact-siblings", "edges": "edges", "firstLabel": "first-label", "hrefTemplate": "href-template", "label": "label", "lastLabel": "last-label", "nextLabel": "next-label", "page": "page", "prevLabel": "prev-label", "siblings": "siblings", "totalPages": "total-pages" }, events: { onDsPageChange: "dsPageChange" }, defineCustomElement: defineDsPagination, displayName: "DsPagination" });

export type DsPlayerEvents = {
  readonly onDsEnded?: (event: CustomEvent<unknown>) => void;
  readonly onDsPause?: (event: CustomEvent<unknown>) => void;
  readonly onDsPlay?: (event: CustomEvent<unknown>) => void;
};
export type DsPlayerProps = Partial<Components.DsPlayer>;
/** `<ds-player>` em React (client). Player de áudio "Ouvir texto" (kit: Player). Em volta de um `<audio>` nativo: */
export const DsPlayer = /* @__PURE__ */ createDsClientComponent<HTMLDsPlayerElement, Components.DsPlayer, DsPlayerEvents>({ tagName: "ds-player", attributes: { "label": "label", "muteLabel": "mute-label", "pauseLabel": "pause-label", "playLabel": "play-label", "preload": "preload", "seekLabel": "seek-label", "src": "src", "unmuteLabel": "unmute-label", "volumeLabel": "volume-label" }, events: { onDsEnded: "dsEnded", onDsPause: "dsPause", onDsPlay: "dsPlay" }, defineCustomElement: defineDsPlayer, displayName: "DsPlayer" });

export type DsQuoteEvents = {};
export type DsQuoteProps = Partial<Components.DsQuote>;
/** `<ds-quote>` em React (client). Citação do kit ("Quote"): `<blockquote>` com filete azul à esquerda, fundo */
export const DsQuote = /* @__PURE__ */ createDsClientComponent<HTMLDsQuoteElement, Components.DsQuote, DsQuoteEvents>({ tagName: "ds-quote", attributes: { "author": "author", "sourceHref": "source-href" }, events: {  }, defineCustomElement: defineDsQuote, displayName: "DsQuote" });

export type DsRadioEvents = {
  readonly onDsChange?: (event: CustomEvent<DsRadioChangeDetail>) => void;
};
export type DsRadioProps = Partial<Components.DsRadio>;
/** `<ds-radio>` em React (client). Botão de rádio nativo estilizado: escolha única dentro de um grupo (mesmo */
export const DsRadio = /* @__PURE__ */ createDsClientComponent<HTMLDsRadioElement, Components.DsRadio, DsRadioEvents>({ tagName: "ds-radio", attributes: { "checked": "checked", "description": "description", "disabled": "disabled", "icon": "icon", "image": "image", "imageAlt": "image-alt", "inputId": "input-id", "label": "label", "name": "name", "value": "value", "variant": "variant" }, events: { onDsChange: "dsChange" }, defineCustomElement: defineDsRadio, displayName: "DsRadio" });

export type DsRangeEvents = {
  readonly onDsChange?: (event: CustomEvent<DsRangeChangeDetail>) => void;
  readonly onDsInput?: (event: CustomEvent<DsRangeChangeDetail>) => void;
};
export type DsRangeProps = Partial<Components.DsRange>;
/** `<ds-range>` em React (client). Controle deslizante (kit "Slider" / "Range"): `<input type="range">` nativo, */
export const DsRange = /* @__PURE__ */ createDsClientComponent<HTMLDsRangeElement, Components.DsRange, DsRangeEvents>({ tagName: "ds-range", attributes: { "disabled": "disabled", "dual": "dual", "endLabel": "end-label", "format": "format", "hideLabel": "hide-label", "hideScale": "hide-scale", "inputId": "input-id", "label": "label", "max": "max", "min": "min", "name": "name", "nameEnd": "name-end", "nameStart": "name-start", "showValue": "show-value", "startLabel": "start-label", "step": "step", "value": "value", "valueEnd": "value-end", "valueStart": "value-start" }, events: { onDsChange: "dsChange", onDsInput: "dsInput" }, defineCustomElement: defineDsRange, displayName: "DsRange" });

export type DsRatingEvents = {};
export type DsRatingProps = Partial<Components.DsRating>;
/** `<ds-rating>` em React (client). Nota com estrelas ("4,8 ★★★★☆ (872)"). Conteúdo puro (zero JS); texto acessível completo. */
export const DsRating = /* @__PURE__ */ createDsClientComponent<HTMLDsRatingElement, Components.DsRating, DsRatingEvents>({ tagName: "ds-rating", attributes: { "count": "count", "max": "max", "value": "value" }, events: {  }, defineCustomElement: defineDsRating, displayName: "DsRating" });

export type DsSearchEvents = {};
export type DsSearchProps = Partial<Components.DsSearch>;
/** `<ds-search>` em React (client). Campo de busca em pílula (referência: "Busque por ex: CNH, Detran, ICMS"). */
export const DsSearch = /* @__PURE__ */ createDsClientComponent<HTMLDsSearchElement, Components.DsSearch, DsSearchEvents>({ tagName: "ds-search", attributes: { "action": "action", "buttonLabel": "button-label", "clearLabel": "clear-label", "clearable": "clearable", "highlight": "highlight", "iconPosition": "icon-position", "inputId": "input-id", "label": "label", "name": "name", "placeholder": "placeholder", "size": "size", "value": "value" }, events: {  }, defineCustomElement: defineDsSearch, displayName: "DsSearch" });

export type DsSectionHeadingEvents = {};
export type DsSectionHeadingProps = Partial<Components.DsSectionHeading>;
/** `<ds-section-heading>` em React (client). Título de seção de página ("Serviços", "Categorias", "Notícias do Estado") */
export const DsSectionHeading = /* @__PURE__ */ createDsClientComponent<HTMLDsSectionHeadingElement, Components.DsSectionHeading, DsSectionHeadingEvents>({ tagName: "ds-section-heading", attributes: { "align": "align", "description": "description", "heading": "heading", "headingId": "heading-id", "headingLevel": "heading-level", "inverse": "inverse" }, events: {  }, defineCustomElement: defineDsSectionHeading, displayName: "DsSectionHeading" });

export type DsSegmentButtonEvents = {
  readonly onDsChange?: (event: CustomEvent<DsSegmentChangeDetail>) => void;
};
export type DsSegmentButtonProps = Partial<Components.DsSegmentButton>;
/** `<ds-segment-button>` em React (client). Botões de segmento (kit "Segment-Button"): escolha única entre poucas opções */
export const DsSegmentButton = /* @__PURE__ */ createDsClientComponent<HTMLDsSegmentButtonElement, Components.DsSegmentButton, DsSegmentButtonEvents>({ tagName: "ds-segment-button", attributes: { "backLabel": "back-label", "disabled": "disabled", "forwardLabel": "forward-label", "hideLabel": "hide-label", "items": "items", "label": "label", "name": "name", "scrollable": "scrollable", "size": "size" }, events: { onDsChange: "dsChange" }, defineCustomElement: defineDsSegmentButton, displayName: "DsSegmentButton" });

export type DsSelectEvents = {
  readonly onDsFooterAction?: (event: CustomEvent<unknown>) => void;
  readonly onDsSelectChange?: (event: CustomEvent<DsSelectChangeDetail>) => void;
};
export type DsSelectProps = Partial<Components.DsSelect>;
/** `<ds-select>` em React (client). Seleção única (referência "Ordenar: A-Z"). Com JavaScript a lista de opções é */
export const DsSelect = /* @__PURE__ */ createDsClientComponent<HTMLDsSelectElement, Components.DsSelect, DsSelectEvents>({ tagName: "ds-select", attributes: { "appearance": "appearance", "disabled": "disabled", "footerActionLabel": "footer-action-label", "fullWidth": "full-width", "hideLabel": "hide-label", "inline": "inline", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "selectId": "select-id", "value": "value" }, events: { onDsFooterAction: "dsFooterAction", onDsSelectChange: "dsSelectChange" }, defineCustomElement: defineDsSelect, displayName: "DsSelect" });

export type DsServiceCardEvents = {};
export type DsServiceCardProps = Partial<Components.DsServiceCard>;
/** `<ds-service-card>` em React (client). Card de serviço da referência: sobretítulo (órgão) e título em azul; com */
export const DsServiceCard = /* @__PURE__ */ createDsClientComponent<HTMLDsServiceCardElement, Components.DsServiceCard, DsServiceCardEvents>({ tagName: "ds-service-card", attributes: { "accent": "accent", "ctaLabel": "cta-label", "external": "external", "eyebrow": "eyebrow", "heading": "heading", "headingLevel": "heading-level", "href": "href", "tags": "tags" }, events: {  }, defineCustomElement: defineDsServiceCard, displayName: "DsServiceCard" });

export type DsSheetEvents = {
  readonly onDsClose?: (event: CustomEvent<unknown>) => void;
};
export type DsSheetProps = Partial<Components.DsSheet>;
/** `<ds-sheet>` em React (client). Painel lateral modal (kit: filtros no celular): entra pela direita sobre um fundo */
export const DsSheet = /* @__PURE__ */ createDsClientComponent<HTMLDsSheetElement, Components.DsSheet, DsSheetEvents>({ tagName: "ds-sheet", attributes: { "closeLabel": "close-label", "heading": "heading", "headingIcon": "heading-icon", "headingLevel": "heading-level", "open": "open" }, events: { onDsClose: "dsClose" }, defineCustomElement: defineDsSheet, displayName: "DsSheet" });

export type DsShortcutCardEvents = {};
export type DsShortcutCardProps = Partial<Components.DsShortcutCard>;
/** `<ds-shortcut-card>` em React (client). Atalho para sistema/app: logotipo, título, descrição e links (lojas, acessar). */
export const DsShortcutCard = /* @__PURE__ */ createDsClientComponent<HTMLDsShortcutCardElement, Components.DsShortcutCard, DsShortcutCardEvents>({ tagName: "ds-shortcut-card", attributes: { "description": "description", "heading": "heading", "headingLevel": "heading-level", "image": "image", "imageAlt": "image-alt" }, events: {  }, defineCustomElement: defineDsShortcutCard, displayName: "DsShortcutCard" });

export type DsSocialCardEvents = {};
export type DsSocialCardProps = Partial<Components.DsSocialCard>;
/** `<ds-social-card>` em React (client). Card "Mais Social" (kit, página Media): faixa verde com texto branco, foto */
export const DsSocialCard = /* @__PURE__ */ createDsClientComponent<HTMLDsSocialCardElement, Components.DsSocialCard, DsSocialCardEvents>({ tagName: "ds-social-card", attributes: { "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt", "logo": "logo", "logoAlt": "logo-alt", "tone": "tone" }, events: {  }, defineCustomElement: defineDsSocialCard, displayName: "DsSocialCard" });

export type DsSplitButtonEvents = {
  readonly onDsSelect?: (event: CustomEvent<DsSplitSelectDetail>) => void;
};
export type DsSplitButtonProps = Partial<Components.DsSplitButton>;
/** `<ds-split-button>` em React (client). Botão dividido (kit "Split-Button"): a ação principal é um `<a>` ou */
export const DsSplitButton = /* @__PURE__ */ createDsClientComponent<HTMLDsSplitButtonElement, Components.DsSplitButton, DsSplitButtonEvents>({ tagName: "ds-split-button", attributes: { "appearance": "appearance", "disabled": "disabled", "href": "href", "icon": "icon", "items": "items", "label": "label", "menuLabel": "menu-label", "rel": "rel", "shape": "shape", "size": "size", "target": "target", "tone": "tone", "type": "type" }, events: { onDsSelect: "dsSelect" }, defineCustomElement: defineDsSplitButton, displayName: "DsSplitButton" });

export type DsStatEvents = {};
export type DsStatProps = Partial<Components.DsStat>;
/** `<ds-stat>` em React (client). Indicador numérico com rótulo ("1200 cartas de serviço"). Conteúdo puro (zero JS). */
export const DsStat = /* @__PURE__ */ createDsClientComponent<HTMLDsStatElement, Components.DsStat, DsStatEvents>({ tagName: "ds-stat", attributes: { "label": "label", "value": "value" }, events: {  }, defineCustomElement: defineDsStat, displayName: "DsStat" });

export type DsStatusEvents = {};
export type DsStatusProps = Partial<Components.DsStatus>;
/** `<ds-status>` em React (client). Situação de um registro: ponto colorido e texto ("Ativado"). Conteúdo puro */
export const DsStatus = /* @__PURE__ */ createDsClientComponent<HTMLDsStatusElement, Components.DsStatus, DsStatusEvents>({ tagName: "ds-status", attributes: { "boxed": "boxed", "tone": "tone" }, events: {  }, defineCustomElement: defineDsStatus, displayName: "DsStatus" });

export type DsStepperEvents = {};
export type DsStepperProps = Partial<Components.DsStepper>;
/** `<ds-stepper>` em React (client). Indicador de progresso em etapas do kit ("Stepper" horizontal, "Step" vertical */
export const DsStepper = /* @__PURE__ */ createDsClientComponent<HTMLDsStepperElement, Components.DsStepper, DsStepperEvents>({ tagName: "ds-stepper", attributes: { "current": "current", "items": "items", "label": "label", "labelsAsChips": "labels-as-chips", "orientation": "orientation" }, events: {  }, defineCustomElement: defineDsStepper, displayName: "DsStepper" });

export type DsStepsEvents = {};
export type DsStepsProps = Partial<Components.DsSteps>;
/** `<ds-steps>` em React (client). Passo a passo numerado com linha de ligação (referência "Como fazer"). Conteúdo puro (zero JS). */
export const DsSteps = /* @__PURE__ */ createDsClientComponent<HTMLDsStepsElement, Components.DsSteps, DsStepsEvents>({ tagName: "ds-steps", attributes: { "headingLevel": "heading-level", "items": "items" }, events: {  }, defineCustomElement: defineDsSteps, displayName: "DsSteps" });

export type DsSummaryEvents = {};
export type DsSummaryProps = Partial<Components.DsSummary>;
/** `<ds-summary>` em React (client). Sumário da página do kit ("Summary"): `<nav>` com a lista de âncoras para os */
export const DsSummary = /* @__PURE__ */ createDsClientComponent<HTMLDsSummaryElement, Components.DsSummary, DsSummaryEvents>({ tagName: "ds-summary", attributes: { "heading": "heading", "items": "items", "label": "label", "track": "track" }, events: {  }, defineCustomElement: defineDsSummary, displayName: "DsSummary" });

export type DsSummaryCardEvents = {};
export type DsSummaryCardProps = Partial<Components.DsSummaryCard>;
/** `<ds-summary-card>` em React (client). Card "Resumo por IA" (kit Card/Resumo IA): cabeçalho azul com título e subtítulo, */
export const DsSummaryCard = /* @__PURE__ */ createDsClientComponent<HTMLDsSummaryCardElement, Components.DsSummaryCard, DsSummaryCardEvents>({ tagName: "ds-summary-card", attributes: { "heading": "heading", "headingLevel": "heading-level", "lessLabel": "less-label", "moreLabel": "more-label", "open": "open", "subheading": "subheading" }, events: {  }, defineCustomElement: defineDsSummaryCard, displayName: "DsSummaryCard" });

export type DsSwitchEvents = {
  readonly onDsChange?: (event: CustomEvent<DsSwitchChangeDetail>) => void;
};
export type DsSwitchProps = Partial<Components.DsSwitch>;
/** `<ds-switch>` em React (client). Chave liga/desliga (kit "Switch"): `<input type="checkbox" role="switch">` real */
export const DsSwitch = /* @__PURE__ */ createDsClientComponent<HTMLDsSwitchElement, Components.DsSwitch, DsSwitchEvents>({ tagName: "ds-switch", attributes: { "checked": "checked", "disabled": "disabled", "inputId": "input-id", "label": "label", "labelPosition": "label-position", "name": "name", "size": "size", "value": "value" }, events: { onDsChange: "dsChange" }, defineCustomElement: defineDsSwitch, displayName: "DsSwitch" });

export type DsTabEvents = {};
export type DsTabProps = Partial<Components.DsTab>;
/** `<ds-tab>` em React (client). Aba do `ds-tabs`. É sempre um link (`<a href>`): para outra página, para uma */
export const DsTab = /* @__PURE__ */ createDsClientComponent<HTMLDsTabElement, Components.DsTab, DsTabEvents>({ tagName: "ds-tab", attributes: { "chevron": "chevron", "disabled": "disabled", "href": "href", "icon": "icon", "panel": "panel", "selected": "selected", "vertical": "vertical", "widget": "widget" }, events: {  }, defineCustomElement: defineDsTab, displayName: "DsTab" });

export type DsTableEvents = {
  readonly onDsAction?: (event: CustomEvent<DsActionDetail>) => void;
  readonly onDsSelectionChange?: (event: CustomEvent<DsSelectionChangeDetail>) => void;
  readonly onDsSort?: (event: CustomEvent<DsSortDetail>) => void;
};
export type DsTableProps = Partial<Components.DsTable>;
/** `<ds-table>` em React (client). Tabela do kit: `<table>` semântica (`<caption>`, `<th scope>`), cabeçalho em */
export const DsTable = /* @__PURE__ */ createDsClientComponent<HTMLDsTableElement, Components.DsTable, DsTableEvents>({ tagName: "ds-table", attributes: { "caption": "caption", "columns": "columns", "emptyText": "empty-text", "hideCaption": "hide-caption", "name": "name", "rows": "rows", "selectAllLabel": "select-all-label", "selectLabel": "select-label", "selectable": "selectable", "sort": "sort", "sortDir": "sort-dir", "sortHrefTemplate": "sort-href-template", "zebra": "zebra" }, events: { onDsAction: "dsAction", onDsSelectionChange: "dsSelectionChange", onDsSort: "dsSort" }, defineCustomElement: defineDsTable, displayName: "DsTable" });

export type DsTabsEvents = {
  readonly onDsTabChange?: (event: CustomEvent<DsTabChangeDetail>) => void;
};
export type DsTabsProps = Partial<Components.DsTabs>;
/** `<ds-tabs>` em React (client). Abas do kit ("Tab"): horizontais com filete azul sob a ativa, ou lista */
export const DsTabs = /* @__PURE__ */ createDsClientComponent<HTMLDsTabsElement, Components.DsTabs, DsTabsEvents>({ tagName: "ds-tabs", attributes: { "label": "label", "orientation": "orientation" }, events: { onDsTabChange: "dsTabChange" }, defineCustomElement: defineDsTabs, displayName: "DsTabs" });

export type DsTagEvents = {
  readonly onDsRemove?: (event: CustomEvent<DsTagRemoveDetail>) => void;
  readonly onDsToggle?: (event: CustomEvent<DsTagToggleDetail>) => void;
};
export type DsTagProps = Partial<Components.DsTag>;
/** `<ds-tag>` em React (client). Chip do kit (Tag / Chips): ícone de check, texto e, à direita, um "x" */
export const DsTag = /* @__PURE__ */ createDsClientComponent<HTMLDsTagElement, Components.DsTag, DsTagEvents>({ tagName: "ds-tag", attributes: { "collapseLabel": "collapse-label", "disabled": "disabled", "expandLabel": "expand-label", "expandable": "expandable", "expanded": "expanded", "icon": "icon", "label": "label", "removable": "removable", "removeLabel": "remove-label", "selected": "selected", "shape": "shape", "size": "size" }, events: { onDsRemove: "dsRemove", onDsToggle: "dsToggle" }, defineCustomElement: defineDsTag, displayName: "DsTag" });

export type DsTextareaEvents = {
  readonly onDsChange?: (event: CustomEvent<DsInputChangeDetail>) => void;
  readonly onDsInput?: (event: CustomEvent<DsInputChangeDetail>) => void;
};
export type DsTextareaProps = Partial<Components.DsTextarea>;
/** `<ds-textarea>` em React (client). Área de texto do kit (TextArea). `<label>` + `<textarea>` nativos no light */
export const DsTextarea = /* @__PURE__ */ createDsClientComponent<HTMLDsTextareaElement, Components.DsTextarea, DsTextareaEvents>({ tagName: "ds-textarea", attributes: { "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "maxlength": "maxlength", "name": "name", "placeholder": "placeholder", "readonly": "readonly", "required": "required", "resize": "resize", "rows": "rows", "status": "status", "value": "value" }, events: { onDsChange: "dsChange", onDsInput: "dsInput" }, defineCustomElement: defineDsTextarea, displayName: "DsTextarea" });

export type DsTileEvents = {};
export type DsTileProps = Partial<Components.DsTile>;
/** `<ds-tile>` em React (client). Bloco de categoria: ícone + rótulo, todo clicável (referência "Categorias"). */
export const DsTile = /* @__PURE__ */ createDsClientComponent<HTMLDsTileElement, Components.DsTile, DsTileEvents>({ tagName: "ds-tile", attributes: { "description": "description", "filled": "filled", "href": "href", "icon": "icon", "linkLabel": "link-label", "narrowVertical": "narrow-vertical", "orientation": "orientation", "tone": "tone" }, events: {  }, defineCustomElement: defineDsTile, displayName: "DsTile" });

export type DsToastEvents = {
  readonly onDsDismiss?: (event: CustomEvent<unknown>) => void;
};
export type DsToastProps = Partial<Components.DsToast>;
/** `<ds-toast>` em React (client). Notificação passageira (kit: Toast): o desenho do `ds-alert` com sombra e a */
export const DsToast = /* @__PURE__ */ createDsClientComponent<HTMLDsToastElement, Components.DsToast, DsToastEvents>({ tagName: "ds-toast", attributes: { "closeLabel": "close-label", "dismissible": "dismissible", "duration": "duration", "heading": "heading", "icon": "icon", "tone": "tone" }, events: { onDsDismiss: "dsDismiss" }, defineCustomElement: defineDsToast, displayName: "DsToast" });

export type DsToasterEvents = {};
export type DsToasterProps = Partial<Components.DsToaster>;
/** `<ds-toaster>` em React (client). Pilha fixa de `ds-toast` num canto da tela (kit: Toast). É a região */
export const DsToaster = /* @__PURE__ */ createDsClientComponent<HTMLDsToasterElement, Components.DsToaster, DsToasterEvents>({ tagName: "ds-toaster", attributes: { "label": "label", "position": "position" }, events: {  }, defineCustomElement: defineDsToaster, displayName: "DsToaster" });

export type DsToggleEvents = {
  readonly onDsToggle?: (event: CustomEvent<DsToggleDetail>) => void;
};
export type DsToggleProps = Partial<Components.DsToggle>;
/** `<ds-toggle>` em React (client). Botão de pressão (kit "Toggle"): um `<button aria-pressed>` cinza que fica */
export const DsToggle = /* @__PURE__ */ createDsClientComponent<HTMLDsToggleElement, Components.DsToggle, DsToggleEvents>({ tagName: "ds-toggle", attributes: { "disabled": "disabled", "icon": "icon", "label": "label", "pressed": "pressed", "size": "size" }, events: { onDsToggle: "dsToggle" }, defineCustomElement: defineDsToggle, displayName: "DsToggle" });

export type DsTooltipEvents = {};
export type DsTooltipProps = Partial<Components.DsTooltip>;
/** `<ds-tooltip>` em React (client). Dica flutuante (kit: Tooltip): caixa escura com seta, em 12 posições */
export const DsTooltip = /* @__PURE__ */ createDsClientComponent<HTMLDsTooltipElement, Components.DsTooltip, DsTooltipEvents>({ tagName: "ds-tooltip", attributes: { "delay": "delay", "placement": "placement", "text": "text", "tooltipId": "tooltip-id" }, events: {  }, defineCustomElement: defineDsTooltip, displayName: "DsTooltip" });

export type DsTopbarEvents = {};
export type DsTopbarProps = Partial<Components.DsTopbar>;
/** `<ds-topbar>` em React (client). Faixa fina do topo de um sistema da área administrativa (kit: Topbar / */
export const DsTopbar = /* @__PURE__ */ createDsClientComponent<HTMLDsTopbarElement, Components.DsTopbar, DsTopbarEvents>({ tagName: "ds-topbar", attributes: { "brandImage": "brand-image", "homeHref": "home-href", "homeLabel": "home-label", "label": "label", "links": "links", "menuLabel": "menu-label" }, events: {  }, defineCustomElement: defineDsTopbar, displayName: "DsTopbar" });
