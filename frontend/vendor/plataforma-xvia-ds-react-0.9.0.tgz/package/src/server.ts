/**
 * GERADO por scripts/generate-wrappers.mjs a partir de @plataforma-xvia/ds-core/dist/docs.json — React Server Components (ADR-007).
 * Não edite: corrija o componente Stencil ou o gerador.
 */

/* eslint-disable */
import type { Components } from "@plataforma-xvia/ds-core/dist/components";
import { createDsServerComponent } from "./runtime/server";

export type { DsServerProps, DsServerComponent } from "./runtime/server";

/** `<ds-accessibility-bar>` no servidor. Barra de acessibilidade do topo (referência ms.gov.br): atalhos "Ir para */
export const DsAccessibilityBar = /* @__PURE__ */ createDsServerComponent<Components.DsAccessibilityBar>({ tag: "ds-accessibility-bar", attributes: { "label": "label", "links": "links" } });

/** `<ds-accordion>` no servidor. Agrupa `ds-accordion-item`s: navegação por setas/Home/End entre os gatilhos */
export const DsAccordion = /* @__PURE__ */ createDsServerComponent<Components.DsAccordion>({ tag: "ds-accordion", attributes: { "exclusive": "exclusive", "separated": "separated", "variant": "variant" } });

/** `<ds-accordion-item>` no servidor. Item de acordeão sobre `<details>/<summary>` nativos: o conteúdo é legível, */
export const DsAccordionItem = /* @__PURE__ */ createDsServerComponent<Components.DsAccordionItem>({ tag: "ds-accordion-item", attributes: { "disabled": "disabled", "heading": "heading", "headingLevel": "heading-level", "headingTone": "heading-tone", "nested": "nested", "open": "open", "standalone": "standalone" } });

/** `<ds-account-panel>` no servidor. Painel lateral da área logada (kit "Menu Lateral"): foto ou iniciais, nome, */
export const DsAccountPanel = /* @__PURE__ */ createDsServerComponent<Components.DsAccountPanel>({ tag: "ds-account-panel", attributes: { "attached": "attached", "backHref": "back-href", "backLabel": "back-label", "items": "items", "itemsHeading": "items-heading", "label": "label", "name": "name", "profileHref": "profile-href", "profileLabel": "profile-label", "src": "src" } });

/** `<ds-alert>` no servidor. Aviso em caixa (kit: Alert): fundo tintado, borda e filete à esquerda no tom, */
export const DsAlert = /* @__PURE__ */ createDsServerComponent<Components.DsAlert>({ tag: "ds-alert", attributes: { "closeLabel": "close-label", "dismissible": "dismissible", "heading": "heading", "icon": "icon", "tone": "tone" } });

/** `<ds-announcement-bar>` no servidor. Faixa de anúncio no topo da página (kit: Top_banner_fixer): fundo */
export const DsAnnouncementBar = /* @__PURE__ */ createDsServerComponent<Components.DsAnnouncementBar>({ tag: "ds-announcement-bar", attributes: { "closeLabel": "close-label", "ctaLabel": "cta-label", "dismissible": "dismissible", "href": "href", "icon": "icon", "label": "label" } });

/** `<ds-app-bar>` no servidor. Barra superior de um sistema da área administrativa (kit: Navbar / System). */
export const DsAppBar = /* @__PURE__ */ createDsServerComponent<Components.DsAppBar>({ tag: "ds-app-bar", attributes: { "appsHref": "apps-href", "appsLabel": "apps-label", "autoCurrent": "auto-current", "brand": "brand", "closeLabel": "close-label", "homeHref": "home-href", "homeLabel": "home-label", "items": "items", "label": "label", "menuLabel": "menu-label", "notificationsCount": "notifications-count", "notificationsHref": "notifications-href", "notificationsLabel": "notifications-label", "searchAction": "search-action", "searchId": "search-id", "searchLabel": "search-label", "searchName": "search-name", "searchPlaceholder": "search-placeholder", "userHref": "user-href", "userImage": "user-image", "userName": "user-name", "variant": "variant" } });

/** `<ds-app-grid>` no servidor. Grade de atalhos de aplicativos (kit: Menu / Apps): três por linha, cada um */
export const DsAppGrid = /* @__PURE__ */ createDsServerComponent<Components.DsAppGrid>({ tag: "ds-app-grid", attributes: { "allHref": "all-href", "allLabel": "all-label", "columns": "columns", "items": "items", "label": "label" } });

/** `<ds-avatar>` no servidor. Avatar do kit: círculo com a foto (`src`); sem foto, as iniciais (`initials` */
export const DsAvatar = /* @__PURE__ */ createDsServerComponent<Components.DsAvatar>({ tag: "ds-avatar", attributes: { "alt": "alt", "initials": "initials", "name": "name", "size": "size", "src": "src", "status": "status", "statusLabel": "status-label" } });

/** `<ds-badge>` no servidor. Etiqueta tonal para categoria, situação ou modalidade. Conteúdo puro (zero JS). */
export const DsBadge = /* @__PURE__ */ createDsServerComponent<Components.DsBadge>({ tag: "ds-badge", attributes: { "icon": "icon", "size": "size", "tone": "tone" } });

/** `<ds-block-card>` no servidor. Card de bloco (kit Card/Block): logotipo redondo à esquerda, título em azul, */
export const DsBlockCard = /* @__PURE__ */ createDsServerComponent<Components.DsBlockCard>({ tag: "ds-block-card", attributes: { "ctaLabel": "cta-label", "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt" } });

/** `<ds-breadcrumb>` no servidor. Trilha de navegação. Conteúdo puro (zero JS): renderiza `nav > ol > li > a` */
export const DsBreadcrumb = /* @__PURE__ */ createDsServerComponent<Components.DsBreadcrumb>({ tag: "ds-breadcrumb", attributes: { "backHref": "back-href", "backLabel": "back-label", "homeIcon": "home-icon", "items": "items", "label": "label" } });

/** `<ds-button>` no servidor. Botão do DS. Renderiza um `<button>` nativo ou, com `href`, um `<a>` — sempre */
export const DsButton = /* @__PURE__ */ createDsServerComponent<Components.DsButton>({ tag: "ds-button", attributes: { "appearance": "appearance", "disabled": "disabled", "download": "download", "fullWidth": "full-width", "href": "href", "icon": "icon", "iconPosition": "icon-position", "label": "label", "loading": "loading", "rel": "rel", "shape": "shape", "size": "size", "target": "target", "tone": "tone", "type": "type", "variant": "variant" } });

/** `<ds-button-group>` no servidor. Contêiner de botões (kit: página Actions). Só layout: CSS e slots, nada de */
export const DsButtonGroup = /* @__PURE__ */ createDsServerComponent<Components.DsButtonGroup>({ tag: "ds-button-group", attributes: { "align": "align", "gap": "gap", "label": "label", "stack": "stack", "wrap": "wrap" } });

/** `<ds-calendar>` no servidor. Calendário mensal (kit: Calendar). Uma `<table>` com `<caption>` do mês, */
export const DsCalendar = /* @__PURE__ */ createDsServerComponent<Components.DsCalendar>({ tag: "ds-calendar", attributes: { "dayHrefTemplate": "day-href-template", "events": "events", "label": "label", "maxEvents": "max-events", "month": "month", "nextHref": "next-href", "nextLabel": "next-label", "prevHref": "prev-href", "prevLabel": "prev-label", "rangeEnd": "range-end", "rangeStart": "range-start", "today": "today", "todayHref": "today-href", "todayLabel": "today-label", "value": "value", "variant": "variant" } });

/** `<ds-card>` no servidor. Superfície de card. Conteúdo puro (zero JS). Com `heading`, o card vira uma */
export const DsCard = /* @__PURE__ */ createDsServerComponent<Components.DsCard>({ tag: "ds-card", attributes: { "brandHeader": "brand-header", "description": "description", "flush": "flush", "heading": "heading", "headingId": "heading-id", "headingLevel": "heading-level", "icon": "icon", "interactive": "interactive", "muted": "muted", "tone": "tone" } });

/** `<ds-carousel>` no servidor. Trilha horizontal com rolagem por snap (banners, atalhos). O conteúdo é HTML */
export const DsCarousel = /* @__PURE__ */ createDsServerComponent<Components.DsCarousel>({ tag: "ds-carousel", attributes: { "dotLabel": "dot-label", "dots": "dots", "itemWidth": "item-width", "label": "label", "narrowOnly": "narrow-only", "nextLabel": "next-label", "prevLabel": "prev-label", "wideOnly": "wide-only" } });

/** `<ds-chart>` no servidor. Gráfico de linhas ou barras da área administrativa (Chart do kit), em SVG */
export const DsChart = /* @__PURE__ */ createDsServerComponent<Components.DsChart>({ tag: "ds-chart", attributes: { "chartId": "chart-id", "decimals": "decimals", "emptyText": "empty-text", "heading": "heading", "height": "height", "labels": "labels", "markers": "markers", "series": "series", "type": "type" } });

/** `<ds-checkbox>` no servidor. Caixa de seleção nativa estilizada. O `<input>` é real e fica no formulário */
export const DsCheckbox = /* @__PURE__ */ createDsServerComponent<Components.DsCheckbox>({ tag: "ds-checkbox", attributes: { "checked": "checked", "description": "description", "disabled": "disabled", "icon": "icon", "image": "image", "imageAlt": "image-alt", "inputId": "input-id", "label": "label", "name": "name", "value": "value", "variant": "variant" } });

/** `<ds-code-input>` no servidor. Código de verificação (kit ".input[2.0] / OPT"): N caixas quadradas, uma por */
export const DsCodeInput = /* @__PURE__ */ createDsServerComponent<Components.DsCodeInput>({ tag: "ds-code-input", attributes: { "alphanumeric": "alphanumeric", "disabled": "disabled", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "length": "length", "name": "name", "status": "status", "value": "value" } });

/** `<ds-combobox>` no servidor. Campo que filtra digitando e escolhe numa lista (referência: "Filtrar */
export const DsCombobox = /* @__PURE__ */ createDsServerComponent<Components.DsCombobox>({ tag: "ds-combobox", attributes: { "disabled": "disabled", "emptyText": "empty-text", "footerActionLabel": "footer-action-label", "fullWidth": "full-width", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "value": "value" } });

/** `<ds-contact-list>` no servidor. Lista de pessoas (kit Card/InfoPersonList): avatar com iniciais (ou foto), nome em */
export const DsContactList = /* @__PURE__ */ createDsServerComponent<Components.DsContactList>({ tag: "ds-contact-list", attributes: { "emptyText": "empty-text", "items": "items", "label": "label", "moreLabel": "more-label" } });

/** `<ds-context-menu>` no servidor. Menu de ações (kit "ContextMenu"): caixa branca com sombra que abre a partir */
export const DsContextMenu = /* @__PURE__ */ createDsServerComponent<Components.DsContextMenu>({ tag: "ds-context-menu", attributes: { "items": "items", "label": "label", "open": "open" } });

/** `<ds-cookie-banner>` no servidor. Faixa de cookies (kit: cookie_banner, LGPD): fundo institucional, ícone de */
export const DsCookieBanner = /* @__PURE__ */ createDsServerComponent<Components.DsCookieBanner>({ tag: "ds-cookie-banner", attributes: { "acceptHref": "accept-href", "acceptLabel": "accept-label", "formAction": "form-action", "label": "label", "name": "name", "settingsHref": "settings-href", "settingsLabel": "settings-label", "static": "static", "value": "value" } });

/** `<ds-divider>` no servidor. Filete separador do kit ("divider"): `<hr>` puro ou, com `label`, um separador */
export const DsDivider = /* @__PURE__ */ createDsServerComponent<Components.DsDivider>({ tag: "ds-divider", attributes: { "dashed": "dashed", "label": "label", "orientation": "orientation" } });

/** `<ds-drawer>` no servidor. Menu lateral da área administrativa (kit: página Menu, "Navbar"). Duas */
export const DsDrawer = /* @__PURE__ */ createDsServerComponent<Components.DsDrawer>({ tag: "ds-drawer", attributes: { "autoCurrent": "auto-current", "collapsed": "collapsed", "helpHref": "help-href", "helpLabel": "help-label", "homeHref": "home-href", "homeLabel": "home-label", "items": "items", "label": "label", "logoutHref": "logout-href", "logoutLabel": "logout-label", "toggleLabel": "toggle-label", "userHref": "user-href", "userImage": "user-image", "userName": "user-name", "workspace": "workspace", "workspaceHref": "workspace-href", "workspaceLabel": "workspace-label" } });

/** `<ds-empty-state>` no servidor. Estado vazio (kit: Empty State): ícone grande, título em negrito, texto */
export const DsEmptyState = /* @__PURE__ */ createDsServerComponent<Components.DsEmptyState>({ tag: "ds-empty-state", attributes: { "compact": "compact", "description": "description", "heading": "heading", "headingLevel": "heading-level", "icon": "icon" } });

/** `<ds-entry-list>` no servidor. Lista de resultados em linhas (referência: catálogo de serviços): sobretítulo em */
export const DsEntryList = /* @__PURE__ */ createDsServerComponent<Components.DsEntryList>({ tag: "ds-entry-list", attributes: { "emptyText": "empty-text", "items": "items", "label": "label" } });

/** `<ds-feedback>` no servidor. "Esta informação foi útil para você?" — sim/não em formulário nativo (`POST` */
export const DsFeedback = /* @__PURE__ */ createDsServerComponent<Components.DsFeedback>({ tag: "ds-feedback", attributes: { "action": "action", "errorHeading": "error-heading", "errorHref": "error-href", "errorLabel": "error-label", "errorText": "error-text", "name": "name", "noLabel": "no-label", "question": "question", "selected": "selected", "thanksText": "thanks-text", "yesLabel": "yes-label" } });

/** `<ds-file-card>` no servidor. Card de arquivo (kit Card/Files): quadrado cinza com o ícone e o tipo (PDF, DOC…) */
export const DsFileCard = /* @__PURE__ */ createDsServerComponent<Components.DsFileCard>({ tag: "ds-file-card", attributes: { "date": "date", "downloadHref": "download-href", "downloadLabel": "download-label", "heading": "heading", "headingLevel": "heading-level", "href": "href", "kind": "kind", "previewHref": "preview-href", "previewLabel": "preview-label", "size": "size" } });

/** `<ds-file-drop>` no servidor. Área de envio de arquivos (kit "Input / File[2.0]"): `<input type="file">` */
export const DsFileDrop = /* @__PURE__ */ createDsServerComponent<Components.DsFileDrop>({ tag: "ds-file-drop", attributes: { "accept": "accept", "disabled": "disabled", "files": "files", "hint": "hint", "inputId": "input-id", "label": "label", "maxSize": "max-size", "multiple": "multiple", "name": "name", "prompt": "prompt", "removeLabel": "remove-label", "required": "required", "status": "status", "uploadingText": "uploading-text" } });

/** `<ds-filter-group>` no servidor. Grupo de filtros recolhível (referência: "Categoria ▾", "Subcategoria ⓘ ▴"): */
export const DsFilterGroup = /* @__PURE__ */ createDsServerComponent<Components.DsFilterGroup>({ tag: "ds-filter-group", attributes: { "heading": "heading", "info": "info", "open": "open" } });

/** `<ds-foot-actions>` no servidor. Barra de ações do rodapé de um formulário (kit: FootActions). A aplicação põe */
export const DsFootActions = /* @__PURE__ */ createDsServerComponent<Components.DsFootActions>({ tag: "ds-foot-actions", attributes: { "align": "align", "autosaveText": "autosave-text", "label": "label", "position": "position" } });

/** `<ds-footer>` no servidor. Rodapé institucional em três faixas (referência ms.gov.br): colunas de links */
export const DsFooter = /* @__PURE__ */ createDsServerComponent<Components.DsFooter>({ tag: "ds-footer", attributes: { "bottomLinks": "bottom-links", "collapsible": "collapsible", "collapsibleLabel": "collapsible-label", "columns": "columns", "variant": "variant" } });

/** `<ds-header>` no servidor. Faixa institucional do topo (fundo da marca): logotipo à esquerda e ações à */
export const DsHeader = /* @__PURE__ */ createDsServerComponent<Components.DsHeader>({ tag: "ds-header", attributes: { "closeLabel": "close-label", "homeHref": "home-href", "homeLabel": "home-label", "menuLabel": "menu-label", "navItems": "nav-items", "navLabel": "nav-label", "secondaryItems": "secondary-items" } });

/** `<ds-icon>` no servidor. Ícone do catálogo `@plataforma-xvia/ds-icons`. Decorativo por padrão */
export const DsIcon = /* @__PURE__ */ createDsServerComponent<Components.DsIcon>({ tag: "ds-icon", attributes: { "label": "label", "name": "name", "size": "size" } });

/** `<ds-image>` no servidor. Imagem com proporção fixa do kit ("Image" / "Aspect"): `<img>` dentro de uma */
export const DsImage = /* @__PURE__ */ createDsServerComponent<Components.DsImage>({ tag: "ds-image", attributes: { "alt": "alt", "caption": "caption", "fit": "fit", "height": "height", "loading": "loading", "ratio": "ratio", "rounded": "rounded", "sizes": "sizes", "src": "src", "srcset": "srcset", "width": "width" } });

/** `<ds-info-system>` no servidor. Linha discreta de informações técnicas do sistema (kit: InfoSystem), em */
export const DsInfoSystem = /* @__PURE__ */ createDsServerComponent<Components.DsInfoSystem>({ tag: "ds-info-system", attributes: { "align": "align", "environment": "environment", "ip": "ip", "items": "items", "label": "label", "published": "published", "publishedLabel": "published-label", "separator": "separator", "system": "system", "version": "version", "versionLabel": "version-label" } });

/** `<ds-input>` no servidor. Campo de texto do kit (Textfield e Textfield 2.0, com Label e texto de ajuda). */
export const DsInput = /* @__PURE__ */ createDsServerComponent<Components.DsInput>({ tag: "ds-input", attributes: { "autocomplete": "autocomplete", "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "icon": "icon", "iconEnd": "icon-end", "inputId": "input-id", "inputmode": "inputmode", "label": "label", "labelPosition": "label-position", "max": "max", "maxlength": "maxlength", "min": "min", "name": "name", "pattern": "pattern", "placeholder": "placeholder", "readonly": "readonly", "required": "required", "size": "size", "status": "status", "step": "step", "type": "type", "value": "value" } });

/** `<ds-kbd>` no servidor. Atalho de teclado do kit ("Hotkey": "Ctrl+K"). Cada tecla vira um `<kbd>` */
export const DsKbd = /* @__PURE__ */ createDsServerComponent<Components.DsKbd>({ tag: "ds-kbd", attributes: { "keys": "keys" } });

/** `<ds-kpi>` no servidor. KPI compacto de painel (Statistics do kit): card pequeno com ícone, rótulo */
export const DsKpi = /* @__PURE__ */ createDsServerComponent<Components.DsKpi>({ tag: "ds-kpi", attributes: { "appearance": "appearance", "help": "help", "icon": "icon", "label": "label", "progress": "progress", "progressLabel": "progress-label", "progressText": "progress-text", "size": "size", "tone": "tone", "value": "value" } });

/** `<ds-link>` no servidor. Link de texto da referência: tons (azul, amarelo, vermelho, neutro), sublinhado */
export const DsLink = /* @__PURE__ */ createDsServerComponent<Components.DsLink>({ tag: "ds-link", attributes: { "external": "external", "href": "href", "icon": "icon", "size": "size", "tone": "tone", "underline": "underline" } });

/** `<ds-link-card>` no servidor. Card com título e lista de links ("Destaques", "Mais acessados"). Cada link */
export const DsLinkCard = /* @__PURE__ */ createDsServerComponent<Components.DsLinkCard>({ tag: "ds-link-card", attributes: { "emptyText": "empty-text", "heading": "heading", "headingLevel": "heading-level", "icon": "icon", "items": "items", "numbered": "numbered" } });

/** `<ds-link-item>` no servidor. Card-linha de link (kit Card/Link): quadrado cinza com o ícone à esquerda, */
export const DsLinkItem = /* @__PURE__ */ createDsServerComponent<Components.DsLinkItem>({ tag: "ds-link-item", attributes: { "external": "external", "eyebrow": "eyebrow", "eyebrowPosition": "eyebrow-position", "heading": "heading", "headingLevel": "heading-level", "href": "href", "icon": "icon", "tinted": "tinted", "underline": "underline" } });

/** `<ds-list>` no servidor. Lista de conteúdo do kit ("List"): `<ul>`/`<ol>` a partir de `items` (JSON). */
export const DsList = /* @__PURE__ */ createDsServerComponent<Components.DsList>({ tag: "ds-list", attributes: { "icon": "icon", "items": "items", "label": "label", "size": "size", "variant": "variant" } });

/** `<ds-media-card>` no servidor. Card de imagem com texto sobreposto (kit: destaque de notícia): foto de fundo, */
export const DsMediaCard = /* @__PURE__ */ createDsServerComponent<Components.DsMediaCard>({ tag: "ds-media-card", attributes: { "category": "category", "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt", "ratio": "ratio" } });

/** `<ds-menu>` no servidor. Lista de itens de menu com seta (referência "Item ›"). Conteúdo puro (zero JS). */
export const DsMenu = /* @__PURE__ */ createDsServerComponent<Components.DsMenu>({ tag: "ds-menu", attributes: { "items": "items", "label": "label" } });

/** `<ds-multi-select>` no servidor. Escolha múltipla por chips (referência: "Órgão" na coluna de filtros). Cada */
export const DsMultiSelect = /* @__PURE__ */ createDsServerComponent<Components.DsMultiSelect>({ tag: "ds-multi-select", attributes: { "chipsLabel": "chips-label", "disabled": "disabled", "emptyText": "empty-text", "fullWidth": "full-width", "hideLabel": "hide-label", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "removeLabel": "remove-label", "selectId": "select-id" } });

/** `<ds-navbar>` no servidor. Barra de navegação principal (faixa branca sob o cabeçalho). Itens com */
export const DsNavbar = /* @__PURE__ */ createDsServerComponent<Components.DsNavbar>({ tag: "ds-navbar", attributes: { "autoCurrent": "auto-current", "items": "items", "label": "label", "narrowHidden": "narrow-hidden" } });

/** `<ds-news-card>` no servidor. Card de notícia. Conteúdo puro: sem estado, sem eventos, sem JavaScript — */
export const DsNewsCard = /* @__PURE__ */ createDsServerComponent<Components.DsNewsCard>({ tag: "ds-news-card", attributes: { "category": "category", "ctaLabel": "cta-label", "date": "date", "excerpt": "excerpt", "external": "external", "headingLevel": "heading-level", "headline": "headline", "href": "href", "image": "image", "imageAlt": "image-alt", "orientation": "orientation", "tags": "tags" } });

/** `<ds-number-input>` no servidor. Campo numérico com botões `+`/`−` empilhados à direita (kit: campo "15" com */
export const DsNumberInput = /* @__PURE__ */ createDsServerComponent<Components.DsNumberInput>({ tag: "ds-number-input", attributes: { "appearance": "appearance", "decrementLabel": "decrement-label", "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "incrementLabel": "increment-label", "inputId": "input-id", "label": "label", "max": "max", "min": "min", "name": "name", "placeholder": "placeholder", "required": "required", "size": "size", "status": "status", "step": "step", "value": "value" } });

/** `<ds-page-header>` no servidor. Cabeçalho de página: trilha, título (h1), descrição, etiquetas e ações. */
export const DsPageHeader = /* @__PURE__ */ createDsServerComponent<Components.DsPageHeader>({ tag: "ds-page-header", attributes: { "description": "description", "eyebrow": "eyebrow", "heading": "heading", "headingLevel": "heading-level", "icon": "icon", "muted": "muted" } });

/** `<ds-pagination>` no servidor. Paginação numerada (anterior, páginas com reticências, próxima; com `edges`, */
export const DsPagination = /* @__PURE__ */ createDsServerComponent<Components.DsPagination>({ tag: "ds-pagination", attributes: { "compactEdges": "compact-edges", "compactSiblings": "compact-siblings", "edges": "edges", "firstLabel": "first-label", "hrefTemplate": "href-template", "label": "label", "lastLabel": "last-label", "nextLabel": "next-label", "page": "page", "prevLabel": "prev-label", "siblings": "siblings", "totalPages": "total-pages" } });

/** `<ds-player>` no servidor. Player de áudio "Ouvir texto" (kit: Player). Em volta de um `<audio>` nativo: */
export const DsPlayer = /* @__PURE__ */ createDsServerComponent<Components.DsPlayer>({ tag: "ds-player", attributes: { "label": "label", "muteLabel": "mute-label", "pauseLabel": "pause-label", "playLabel": "play-label", "preload": "preload", "seekLabel": "seek-label", "src": "src", "unmuteLabel": "unmute-label", "volumeLabel": "volume-label" } });

/** `<ds-quote>` no servidor. Citação do kit ("Quote"): `<blockquote>` com filete azul à esquerda, fundo */
export const DsQuote = /* @__PURE__ */ createDsServerComponent<Components.DsQuote>({ tag: "ds-quote", attributes: { "author": "author", "sourceHref": "source-href" } });

/** `<ds-radio>` no servidor. Botão de rádio nativo estilizado: escolha única dentro de um grupo (mesmo */
export const DsRadio = /* @__PURE__ */ createDsServerComponent<Components.DsRadio>({ tag: "ds-radio", attributes: { "checked": "checked", "description": "description", "disabled": "disabled", "icon": "icon", "image": "image", "imageAlt": "image-alt", "inputId": "input-id", "label": "label", "name": "name", "value": "value", "variant": "variant" } });

/** `<ds-range>` no servidor. Controle deslizante (kit "Slider" / "Range"): `<input type="range">` nativo, */
export const DsRange = /* @__PURE__ */ createDsServerComponent<Components.DsRange>({ tag: "ds-range", attributes: { "disabled": "disabled", "dual": "dual", "endLabel": "end-label", "format": "format", "hideLabel": "hide-label", "hideScale": "hide-scale", "inputId": "input-id", "label": "label", "max": "max", "min": "min", "name": "name", "nameEnd": "name-end", "nameStart": "name-start", "showValue": "show-value", "startLabel": "start-label", "step": "step", "value": "value", "valueEnd": "value-end", "valueStart": "value-start" } });

/** `<ds-rating>` no servidor. Nota com estrelas ("4,8 ★★★★☆ (872)"). Conteúdo puro (zero JS); texto acessível completo. */
export const DsRating = /* @__PURE__ */ createDsServerComponent<Components.DsRating>({ tag: "ds-rating", attributes: { "count": "count", "max": "max", "value": "value" } });

/** `<ds-search>` no servidor. Campo de busca em pílula (referência: "Busque por ex: CNH, Detran, ICMS"). */
export const DsSearch = /* @__PURE__ */ createDsServerComponent<Components.DsSearch>({ tag: "ds-search", attributes: { "action": "action", "buttonLabel": "button-label", "clearLabel": "clear-label", "clearable": "clearable", "highlight": "highlight", "iconPosition": "icon-position", "inputId": "input-id", "label": "label", "name": "name", "placeholder": "placeholder", "size": "size", "value": "value" } });

/** `<ds-section-heading>` no servidor. Título de seção de página ("Serviços", "Categorias", "Notícias do Estado") */
export const DsSectionHeading = /* @__PURE__ */ createDsServerComponent<Components.DsSectionHeading>({ tag: "ds-section-heading", attributes: { "align": "align", "description": "description", "heading": "heading", "headingId": "heading-id", "headingLevel": "heading-level", "inverse": "inverse" } });

/** `<ds-segment-button>` no servidor. Botões de segmento (kit "Segment-Button"): escolha única entre poucas opções */
export const DsSegmentButton = /* @__PURE__ */ createDsServerComponent<Components.DsSegmentButton>({ tag: "ds-segment-button", attributes: { "backLabel": "back-label", "disabled": "disabled", "forwardLabel": "forward-label", "hideLabel": "hide-label", "items": "items", "label": "label", "name": "name", "scrollable": "scrollable", "size": "size" } });

/** `<ds-select>` no servidor. Seleção única (referência "Ordenar: A-Z"). Com JavaScript a lista de opções é */
export const DsSelect = /* @__PURE__ */ createDsServerComponent<Components.DsSelect>({ tag: "ds-select", attributes: { "appearance": "appearance", "disabled": "disabled", "footerActionLabel": "footer-action-label", "fullWidth": "full-width", "hideLabel": "hide-label", "inline": "inline", "label": "label", "name": "name", "options": "options", "placeholder": "placeholder", "selectId": "select-id", "value": "value" } });

/** `<ds-service-card>` no servidor. Card de serviço da referência: sobretítulo (órgão) e título em azul; com */
export const DsServiceCard = /* @__PURE__ */ createDsServerComponent<Components.DsServiceCard>({ tag: "ds-service-card", attributes: { "accent": "accent", "ctaLabel": "cta-label", "external": "external", "eyebrow": "eyebrow", "heading": "heading", "headingLevel": "heading-level", "href": "href", "tags": "tags" } });

/** `<ds-sheet>` no servidor. Painel lateral modal (kit: filtros no celular): entra pela direita sobre um fundo */
export const DsSheet = /* @__PURE__ */ createDsServerComponent<Components.DsSheet>({ tag: "ds-sheet", attributes: { "closeLabel": "close-label", "heading": "heading", "headingIcon": "heading-icon", "headingLevel": "heading-level", "open": "open" } });

/** `<ds-shortcut-card>` no servidor. Atalho para sistema/app: logotipo, título, descrição e links (lojas, acessar). */
export const DsShortcutCard = /* @__PURE__ */ createDsServerComponent<Components.DsShortcutCard>({ tag: "ds-shortcut-card", attributes: { "description": "description", "heading": "heading", "headingLevel": "heading-level", "image": "image", "imageAlt": "image-alt" } });

/** `<ds-social-card>` no servidor. Card "Mais Social" (kit, página Media): faixa verde com texto branco, foto */
export const DsSocialCard = /* @__PURE__ */ createDsServerComponent<Components.DsSocialCard>({ tag: "ds-social-card", attributes: { "description": "description", "external": "external", "heading": "heading", "headingLevel": "heading-level", "href": "href", "image": "image", "imageAlt": "image-alt", "logo": "logo", "logoAlt": "logo-alt", "tone": "tone" } });

/** `<ds-split-button>` no servidor. Botão dividido (kit "Split-Button"): a ação principal é um `<a>` ou */
export const DsSplitButton = /* @__PURE__ */ createDsServerComponent<Components.DsSplitButton>({ tag: "ds-split-button", attributes: { "appearance": "appearance", "disabled": "disabled", "href": "href", "icon": "icon", "items": "items", "label": "label", "menuLabel": "menu-label", "rel": "rel", "shape": "shape", "size": "size", "target": "target", "tone": "tone", "type": "type" } });

/** `<ds-stat>` no servidor. Indicador numérico com rótulo ("1200 cartas de serviço"). Conteúdo puro (zero JS). */
export const DsStat = /* @__PURE__ */ createDsServerComponent<Components.DsStat>({ tag: "ds-stat", attributes: { "label": "label", "value": "value" } });

/** `<ds-status>` no servidor. Situação de um registro: ponto colorido e texto ("Ativado"). Conteúdo puro */
export const DsStatus = /* @__PURE__ */ createDsServerComponent<Components.DsStatus>({ tag: "ds-status", attributes: { "boxed": "boxed", "tone": "tone" } });

/** `<ds-stepper>` no servidor. Indicador de progresso em etapas do kit ("Stepper" horizontal, "Step" vertical */
export const DsStepper = /* @__PURE__ */ createDsServerComponent<Components.DsStepper>({ tag: "ds-stepper", attributes: { "current": "current", "items": "items", "label": "label", "labelsAsChips": "labels-as-chips", "orientation": "orientation" } });

/** `<ds-steps>` no servidor. Passo a passo numerado com linha de ligação (referência "Como fazer"). Conteúdo puro (zero JS). */
export const DsSteps = /* @__PURE__ */ createDsServerComponent<Components.DsSteps>({ tag: "ds-steps", attributes: { "headingLevel": "heading-level", "items": "items" } });

/** `<ds-summary>` no servidor. Sumário da página do kit ("Summary"): `<nav>` com a lista de âncoras para os */
export const DsSummary = /* @__PURE__ */ createDsServerComponent<Components.DsSummary>({ tag: "ds-summary", attributes: { "heading": "heading", "items": "items", "label": "label", "track": "track" } });

/** `<ds-summary-card>` no servidor. Card "Resumo por IA" (kit Card/Resumo IA): cabeçalho azul com título e subtítulo, */
export const DsSummaryCard = /* @__PURE__ */ createDsServerComponent<Components.DsSummaryCard>({ tag: "ds-summary-card", attributes: { "heading": "heading", "headingLevel": "heading-level", "lessLabel": "less-label", "moreLabel": "more-label", "open": "open", "subheading": "subheading" } });

/** `<ds-switch>` no servidor. Chave liga/desliga (kit "Switch"): `<input type="checkbox" role="switch">` real */
export const DsSwitch = /* @__PURE__ */ createDsServerComponent<Components.DsSwitch>({ tag: "ds-switch", attributes: { "checked": "checked", "disabled": "disabled", "inputId": "input-id", "label": "label", "labelPosition": "label-position", "name": "name", "size": "size", "value": "value" } });

/** `<ds-tab>` no servidor. Aba do `ds-tabs`. É sempre um link (`<a href>`): para outra página, para uma */
export const DsTab = /* @__PURE__ */ createDsServerComponent<Components.DsTab>({ tag: "ds-tab", attributes: { "chevron": "chevron", "disabled": "disabled", "href": "href", "icon": "icon", "panel": "panel", "selected": "selected", "vertical": "vertical", "widget": "widget" } });

/** `<ds-table>` no servidor. Tabela do kit: `<table>` semântica (`<caption>`, `<th scope>`), cabeçalho em */
export const DsTable = /* @__PURE__ */ createDsServerComponent<Components.DsTable>({ tag: "ds-table", attributes: { "caption": "caption", "columns": "columns", "emptyText": "empty-text", "hideCaption": "hide-caption", "name": "name", "rows": "rows", "selectAllLabel": "select-all-label", "selectLabel": "select-label", "selectable": "selectable", "sort": "sort", "sortDir": "sort-dir", "sortHrefTemplate": "sort-href-template", "zebra": "zebra" } });

/** `<ds-tabs>` no servidor. Abas do kit ("Tab"): horizontais com filete azul sob a ativa, ou lista */
export const DsTabs = /* @__PURE__ */ createDsServerComponent<Components.DsTabs>({ tag: "ds-tabs", attributes: { "label": "label", "orientation": "orientation" } });

/** `<ds-tag>` no servidor. Chip do kit (Tag / Chips): ícone de check, texto e, à direita, um "x" */
export const DsTag = /* @__PURE__ */ createDsServerComponent<Components.DsTag>({ tag: "ds-tag", attributes: { "collapseLabel": "collapse-label", "disabled": "disabled", "expandLabel": "expand-label", "expandable": "expandable", "expanded": "expanded", "icon": "icon", "label": "label", "removable": "removable", "removeLabel": "remove-label", "selected": "selected", "shape": "shape", "size": "size" } });

/** `<ds-textarea>` no servidor. Área de texto do kit (TextArea). `<label>` + `<textarea>` nativos no light */
export const DsTextarea = /* @__PURE__ */ createDsServerComponent<Components.DsTextarea>({ tag: "ds-textarea", attributes: { "disabled": "disabled", "help": "help", "hideLabel": "hide-label", "inputId": "input-id", "label": "label", "maxlength": "maxlength", "name": "name", "placeholder": "placeholder", "readonly": "readonly", "required": "required", "resize": "resize", "rows": "rows", "status": "status", "value": "value" } });

/** `<ds-tile>` no servidor. Bloco de categoria: ícone + rótulo, todo clicável (referência "Categorias"). */
export const DsTile = /* @__PURE__ */ createDsServerComponent<Components.DsTile>({ tag: "ds-tile", attributes: { "description": "description", "filled": "filled", "href": "href", "icon": "icon", "linkLabel": "link-label", "narrowVertical": "narrow-vertical", "orientation": "orientation", "tone": "tone" } });

/** `<ds-toast>` no servidor. Notificação passageira (kit: Toast): o desenho do `ds-alert` com sombra e a */
export const DsToast = /* @__PURE__ */ createDsServerComponent<Components.DsToast>({ tag: "ds-toast", attributes: { "closeLabel": "close-label", "dismissible": "dismissible", "duration": "duration", "heading": "heading", "icon": "icon", "tone": "tone" } });

/** `<ds-toaster>` no servidor. Pilha fixa de `ds-toast` num canto da tela (kit: Toast). É a região */
export const DsToaster = /* @__PURE__ */ createDsServerComponent<Components.DsToaster>({ tag: "ds-toaster", attributes: { "label": "label", "position": "position" } });

/** `<ds-toggle>` no servidor. Botão de pressão (kit "Toggle"): um `<button aria-pressed>` cinza que fica */
export const DsToggle = /* @__PURE__ */ createDsServerComponent<Components.DsToggle>({ tag: "ds-toggle", attributes: { "disabled": "disabled", "icon": "icon", "label": "label", "pressed": "pressed", "size": "size" } });

/** `<ds-tooltip>` no servidor. Dica flutuante (kit: Tooltip): caixa escura com seta, em 12 posições */
export const DsTooltip = /* @__PURE__ */ createDsServerComponent<Components.DsTooltip>({ tag: "ds-tooltip", attributes: { "delay": "delay", "placement": "placement", "text": "text", "tooltipId": "tooltip-id" } });

/** `<ds-topbar>` no servidor. Faixa fina do topo de um sistema da área administrativa (kit: Topbar / */
export const DsTopbar = /* @__PURE__ */ createDsServerComponent<Components.DsTopbar>({ tag: "ds-topbar", attributes: { "brandImage": "brand-image", "homeHref": "home-href", "homeLabel": "home-label", "label": "label", "links": "links", "menuLabel": "menu-label" } });
