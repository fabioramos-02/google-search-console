"use client";

import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  type CSSProperties,
  type HTMLAttributes,
  type ReactNode,
} from "react";

/** `onDsToggle` → `"dsToggle"` (nome do CustomEvent). */
export type DsEventMap = Readonly<Record<string, string>>;

export interface DsClientComponentOptions {
  readonly tagName: string;
  /** prop → atributo (do docs.json do core). */
  readonly attributes: Readonly<Record<string, string>>;
  readonly events: DsEventMap;
  readonly defineCustomElement: () => void;
  readonly displayName: string;
}

type HostAttributes = Omit<HTMLAttributes<HTMLElement>, "children" | "style"> & {
  readonly className?: string | undefined;
  readonly style?: CSSProperties | undefined;
  readonly slot?: string | undefined;
};

/** Props públicas: props do elemento (todas opcionais, `undefined` aceito) + eventos tipados + atributos de host. */
export type DsClientProps<P, E> = { readonly [K in keyof P]?: P[K] | undefined } & E &
  Omit<HostAttributes, keyof P | keyof E> & {
    readonly children?: ReactNode;
  };

export type DsClientComponent<I extends HTMLElement, P, E> = React.ForwardRefExoticComponent<
  DsClientProps<P, E> & React.RefAttributes<I>
>;

const useIsomorphicLayoutEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;

/**
 * Wrapper client de um custom element — SSR-compatível, não SSR-only (ADR-008).
 *
 * - Props primitivas viram ATRIBUTOS (nome kebab do Stencil): no servidor saem no
 *   light DOM, exatamente o que o React hidrata; no cliente o React só toca no que
 *   mudou entre renders, então o estado interno do componente (ex.: `open`) não é
 *   sobrescrito a cada render. Objetos viram propriedades, num layout effect.
 * - Eventos (`onDsToggle`) viram listeners do CustomEvent, religados a cada render
 *   (barato, e imune à desmontagem simulada do StrictMode).
 * - O custom element é REGISTRADO num efeito, depois da hidratação: registrar ao
 *   importar faz o Stencil reescrever o DOM antes de o React hidratar (mismatch).
 *   Em apps só cliente (Vite) o efeito roda logo após o mount.
 */
export function createDsClientComponent<I extends HTMLElement, P, E>(
  options: DsClientComponentOptions,
): DsClientComponent<I, P, E> {
  const Component = forwardRef<I, DsClientProps<P, E>>((props, ref) => {
    const elementRef = useRef<I | null>(null);
    useImperativeHandle(ref, () => elementRef.current as I, []);

    const { children, ...rest } = props as { readonly children?: ReactNode } & Record<
      string,
      unknown
    >;
    const attributes: Record<string, unknown> = {};
    const properties: Record<string, unknown> = {};
    const handlers: Record<string, EventListener | undefined> = {};
    for (const [key, value] of Object.entries(rest)) {
      const eventName = options.events[key];
      if (eventName !== undefined) {
        handlers[eventName] = value as EventListener | undefined;
        continue;
      }
      const attribute = options.attributes[key];
      if (attribute === undefined) {
        attributes[key] = value;
        continue;
      }
      if (value === undefined || value === null || value === false) continue;
      if (value === true) {
        attributes[attribute] = "";
      } else if (typeof value === "string" || typeof value === "number") {
        attributes[attribute] = String(value);
      } else {
        properties[key] = value;
      }
    }

    const propertiesRef = useRef<Record<string, unknown>>({});
    useIsomorphicLayoutEffect(() => {
      const element = elementRef.current as unknown as Record<string, unknown> | null;
      if (element === null) return;
      for (const [key, value] of Object.entries(properties)) {
        if (propertiesRef.current[key] !== value) element[key] = value;
      }
      propertiesRef.current = properties;
    });

    // Liga e desliga no MESMO efeito, a cada render. A versão anterior comparava a
    // identidade do handler entre renders e tinha um efeito de desmontagem à parte:
    // sob StrictMode (Next em dev) a desmontagem simulada removia o listener e a
    // remontagem, vendo o mesmo handler, pulava o `addEventListener` — o evento
    // nunca mais chegava ao React até um render com função nova.
    useIsomorphicLayoutEffect(() => {
      const element = elementRef.current;
      if (element === null) return undefined;
      const bound: Array<readonly [string, EventListener]> = [];
      for (const [eventName, handler] of Object.entries(handlers)) {
        if (handler === undefined) continue;
        element.addEventListener(eventName, handler);
        bound.push([eventName, handler]);
      }
      return () => {
        for (const [eventName, handler] of bound) element.removeEventListener(eventName, handler);
      };
    });

    useEffect(() => {
      options.defineCustomElement();
    }, []);

    return React.createElement(options.tagName, { ...attributes, ref: elementRef }, children);
  });
  Component.displayName = options.displayName;
  return Component as unknown as DsClientComponent<I, P, E>;
}
