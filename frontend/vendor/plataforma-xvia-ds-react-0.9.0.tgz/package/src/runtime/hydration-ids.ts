/**
 * Os ids do hydrate do Stencil (`s-id`, `c-id`, comentários `r/t/s/o`) vêm de um
 * contador do processo e mudam a cada render. Aqui passam a derivar do conteúdo,
 * para renders iguais darem HTML igual.
 */
const HYDRATION_TOKEN = /(s-id="|c-id="|<!--[a-z]\.)(\d+)(\.(\d+))?(?=["\-.])/g;
const DOCUMENT_HOST = "0";
const NODE_ID_SPAN = 1_000;

type Mapping = {
  readonly host: (id: string) => string;
  readonly node: (id: string) => string;
};

function rewrite(html: string, mapping: Mapping): string {
  return html.replace(
    HYDRATION_TOKEN,
    (_match, prefix: string, host: string, tail: string | undefined, node: string | undefined) => {
      if (host === DOCUMENT_HOST && node !== undefined)
        return `${prefix}${host}.${mapping.node(node)}`;
      return `${prefix}${mapping.host(host)}${tail ?? ""}`;
    },
  );
}

function indexer(): { readonly map: (id: string) => string; readonly ids: string[] } {
  const ids: string[] = [];
  return {
    ids,
    map: (id) => {
      let index = ids.indexOf(id);
      if (index === -1) index = ids.push(id) - 1;
      return String(index + 1);
    },
  };
}

/** FNV-1a de 32 bits, positivo e acima dos ids pequenos que o hydrate distribui. */
function fnv1a(text: string): number {
  let hash = 0x811c9dc5;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return (hash % 1_000_000_000) + 1_000_000;
}

/** Primeiro id livre a partir do preferido: raízes idênticas na mesma página não dividem id. */
export function claimHydrationId(preferred: number, taken: Set<number>): string {
  let id = preferred;
  while (taken.has(id)) id += 1;
  taken.add(id);
  return String(id);
}

/**
 * Troca todos os números voláteis do hydrate por ids estáveis derivados do conteúdo.
 * `claim` reserva cada id de host na requisição (`claimHydrationId`).
 */
export function stabilizeHydrationIds(html: string, claim: (preferred: number) => string): string {
  const hosts = indexer();
  const nodes = indexer();
  const normalized = rewrite(html, { host: hosts.map, node: nodes.map });
  const base = fnv1a(normalized);
  const hostIds = hosts.ids.map((_id, index) => claim(base + index));
  return rewrite(html, {
    host: (id) => hostIds[hosts.ids.indexOf(id)] ?? id,
    node: (id) => String(base * NODE_ID_SPAN + nodes.ids.indexOf(id) + 1),
  });
}
