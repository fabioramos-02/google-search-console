import { Fragment, isValidElement, type ReactNode } from "react";
import { escapeAttribute, escapeHtml, toAttributeName } from "./escape";

/**
 * Serializa uma subárvore React para HTML **no servidor**, sem `react-dom/server`
 * (que não existe em React Server Components). Aceita: texto, números, arrays,
 * fragmentos, elementos HTML nativos, componentes de servidor do DS (marcados com
 * DS_SERVER) e funções de componente puras (chamadas diretamente). Qualquer outra
 * coisa — componentes client, classes — é erro explícito: no servidor o conteúdo
 * de um componente do DS é HTML, não React interativo (ADR-007).
 */

export const DS_SERVER: unique symbol = Symbol.for("xvia.ds.server-component");

export interface DsServerComponentOptions {
  readonly tag: string;
  /** prop → atributo (do docs.json do core). */
  readonly attributes: Readonly<Record<string, string>>;
}

export interface DsServerMarked {
  readonly [DS_SERVER]: DsServerComponentOptions;
}

/**
 * Ilha client dentro de um componente do DS renderizado no servidor (ADR-010):
 * `node` é React de verdade (componentes client incluídos), montado no cliente
 * por portal dentro do slot; `fallback` é HTML puro que sai no servidor e some
 * quando a ilha monta.
 */
export interface DsIsland {
  readonly node: ReactNode;
  readonly fallback?: ReactNode;
}

export const ISLAND_ATTRIBUTE = "data-ds-island";

const VOID_ELEMENTS = new Set([
  "area",
  "base",
  "br",
  "col",
  "embed",
  "hr",
  "img",
  "input",
  "link",
  "meta",
  "source",
  "track",
  "wbr",
]);

const ATTRIBUTE_ALIASES: Readonly<Record<string, string>> = {
  className: "class",
  htmlFor: "for",
  httpEquiv: "http-equiv",
  acceptCharset: "accept-charset",
  tabIndex: "tabindex",
  readOnly: "readonly",
  maxLength: "maxlength",
  dateTime: "datetime",
  srcSet: "srcset",
  crossOrigin: "crossorigin",
  autoComplete: "autocomplete",
};

// Atributos SVG que são camelCase na própria especificação: em kebab-case o
// navegador os ignora (ex.: `view-box` recorta o ícone fora de 24px).
const SVG_CAMEL_CASE_ATTRIBUTES = new Set([
  "viewBox",
  "preserveAspectRatio",
  "gradientTransform",
  "gradientUnits",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "clipPathUnits",
  "maskContentUnits",
  "maskUnits",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "refX",
  "refY",
  "pathLength",
  "spreadMethod",
  "stdDeviation",
  "textLength",
  "lengthAdjust",
]);

const SKIPPED_PROPS = new Set([
  "children",
  "key",
  "ref",
  "dangerouslySetInnerHTML",
  "suppressHydrationWarning",
]);

export function styleToString(style: Record<string, unknown>): string {
  return Object.entries(style)
    .filter(([, value]) => value !== undefined && value !== null && value !== false)
    .map(([name, value]) => {
      const cssName = name.startsWith("--")
        ? name
        : name.replace(/[A-Z]/g, (char) => `-${char.toLowerCase()}`);
      const cssValue =
        typeof value === "number" &&
        value !== 0 &&
        !/^(opacity|z-index|flex|order|line-height|font-weight)$/.test(cssName)
          ? `${value}px`
          : String(value);
      return `${cssName}:${cssValue}`;
    })
    .join(";");
}

export function attributesToString(
  props: Record<string, unknown>,
  extraSkip: ReadonlySet<string> = new Set(),
): string {
  let out = "";
  for (const [prop, value] of Object.entries(props)) {
    if (SKIPPED_PROPS.has(prop) || extraSkip.has(prop)) continue;
    if (value === undefined || value === null || value === false) continue;
    if (typeof value === "function") {
      throw new Error(
        `[ds-react/server] A prop "${prop}" é uma função; handlers não existem no servidor. Use @plataforma-xvia/ds-react (client) para interatividade.`,
      );
    }
    const name =
      ATTRIBUTE_ALIASES[prop] ??
      (prop.startsWith("data-") || prop.startsWith("aria-") || SVG_CAMEL_CASE_ATTRIBUTES.has(prop)
        ? prop
        : toAttributeName(prop));
    if (value === true) {
      out += ` ${name}=""`;
      continue;
    }
    if (prop === "style" && typeof value === "object") {
      out += ` style="${escapeAttribute(styleToString(value as Record<string, unknown>))}"`;
      continue;
    }
    if (typeof value === "object") {
      throw new Error(
        `[ds-react/server] A prop "${prop}" é um objeto; só valores serializáveis em atributo são aceitos no servidor.`,
      );
    }
    out += ` ${name}="${escapeAttribute(String(value))}"`;
  }
  return out;
}

function isDsServer(type: unknown): type is DsServerMarked {
  return typeof type === "function" && DS_SERVER in type;
}

export async function nodeToHtml(node: ReactNode): Promise<string> {
  if (node === null || node === undefined || typeof node === "boolean") return "";
  if (typeof node === "string") return escapeHtml(node);
  if (typeof node === "number" || typeof node === "bigint") return String(node);
  if (Array.isArray(node)) {
    const parts = await Promise.all(node.map((child) => nodeToHtml(child as ReactNode)));
    return parts.join("");
  }
  if (
    typeof node === "object" &&
    "then" in node &&
    typeof (node as PromiseLike<ReactNode>).then === "function"
  ) {
    return nodeToHtml(await (node as PromiseLike<ReactNode>));
  }
  if (!isValidElement(node)) {
    throw new Error("[ds-react/server] Nó React não serializável no servidor.");
  }
  const { type, props } = node as { type: unknown; props: Record<string, unknown> };
  if (type === Fragment) {
    return nodeToHtml(props.children as ReactNode);
  }
  if (typeof type === "string") {
    const inner =
      props.dangerouslySetInnerHTML !== undefined
        ? String((props.dangerouslySetInnerHTML as { __html?: unknown }).__html ?? "")
        : await nodeToHtml(props.children as ReactNode);
    if (VOID_ELEMENTS.has(type)) return `<${type}${attributesToString(props)}>`;
    return `<${type}${attributesToString(props)}>${inner}</${type}>`;
  }
  if (isDsServer(type)) {
    return dsElementToHtml(type[DS_SERVER], props);
  }
  if (typeof type === "function") {
    const result = (type as (p: Record<string, unknown>) => ReactNode | Promise<ReactNode>)(props);
    return nodeToHtml(await result);
  }
  throw new Error(
    "[ds-react/server] Filho não suportado no servidor (componente client ou classe). Dentro de um componente do DS renderizado no servidor só entram HTML, texto e outros componentes do DS.",
  );
}

/** Placeholders das ilhas: `<span slot="nome" data-ds-island="nome">fallback</span>`. */
export async function islandsToHtml(
  islands: Readonly<Record<string, DsIsland>> | undefined,
): Promise<string> {
  if (islands === undefined) return "";
  let out = "";
  for (const [name, island] of Object.entries(islands)) {
    if (!/^[a-z][a-z0-9-]*$/i.test(name)) {
      throw new Error(`[ds-react/server] Nome de ilha inválido: "${name}" (use o nome do slot).`);
    }
    const fallback = await nodeToHtml(island.fallback);
    out += `<span slot="${escapeAttribute(name)}" ${ISLAND_ATTRIBUTE}="${escapeAttribute(name)}">${fallback}</span>`;
  }
  return out;
}

/** Tag crua do custom element, sem chamar o hydrate — quem chama o hydrate é só o componente raiz. */
export async function dsElementToHtml(
  options: DsServerComponentOptions,
  props: Record<string, unknown>,
  islands?: Readonly<Record<string, DsIsland>>,
): Promise<string> {
  const { children, className, id, slot, hostAttributes, ...rest } = props as {
    children?: ReactNode;
    className?: string;
    id?: string;
    slot?: string;
    hostAttributes?: Record<string, string | number | boolean | undefined>;
  } & Record<string, unknown>;
  if ("islands" in rest) {
    throw new Error(
      `[ds-react/server] "islands" só é aceito no componente do DS mais externo (<${options.tag}> está aninhado).`,
    );
  }
  let attrs = "";
  for (const [prop, value] of Object.entries(rest)) {
    if (value === undefined || value === null || value === false) continue;
    const attr = options.attributes[prop];
    if (attr === undefined) {
      throw new Error(
        `[ds-react/server] "${prop}" não é prop de <${options.tag}>. Eventos e props de instância não existem no servidor.`,
      );
    }
    if (typeof value === "function" || typeof value === "object") {
      throw new Error(
        `[ds-react/server] A prop "${prop}" de <${options.tag}> precisa ser string, número ou booleano no servidor.`,
      );
    }
    attrs += value === true ? ` ${attr}=""` : ` ${attr}="${escapeAttribute(String(value))}"`;
  }
  const host: Record<string, unknown> = { ...hostAttributes };
  if (className !== undefined) host.class = className;
  if (id !== undefined) host.id = id;
  if (slot !== undefined) host.slot = slot;
  attrs += attributesToString(host);
  const inner = await nodeToHtml(children);
  const islandsHtml = await islandsToHtml(islands);
  return `<${options.tag}${attrs}>${inner}${islandsHtml}</${options.tag}>`;
}
