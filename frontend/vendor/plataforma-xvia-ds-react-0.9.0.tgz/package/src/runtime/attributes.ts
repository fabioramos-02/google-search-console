/**
 * Atributos do host devolvidos pelo hydrate do Stencil. O hydrate serializa os
 * valores escapados (`&amp;`, `&quot;`, `&nbsp;`); o React vai escapar de novo ao
 * renderizar, então aqui eles voltam ao texto original — senão um atributo JSON
 * (`items` do `ds-breadcrumb`) ou um título com `&` chega quebrado ao cliente.
 */
const NAMED_ENTITIES: Readonly<Record<string, string>> = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'",
  nbsp: " ",
};

const ENTITY = /&(#x[0-9a-f]+|#\d+|[a-z]+);/gi;
const MAX_CODE_POINT = 0x10ffff;

export function decodeHtmlEntities(value: string): string {
  if (!value.includes("&")) return value;
  return value.replace(ENTITY, (match, entity: string) => {
    if (entity.startsWith("#")) {
      const isHex = entity[1] === "x" || entity[1] === "X";
      const code = isHex
        ? Number.parseInt(entity.slice(2), 16)
        : Number.parseInt(entity.slice(1), 10);
      if (Number.isNaN(code) || code > MAX_CODE_POINT) return match;
      return String.fromCodePoint(code);
    }
    return NAMED_ENTITIES[entity.toLowerCase()] ?? match;
  });
}

const ATTRIBUTE = /([^\s=]+)(?:="([^"]*)")?/g;

/** `raw` é o miolo da tag de abertura (` a="1" b`), como sai do hydrate. */
export function parseAttributes(raw: string): Record<string, string> {
  const attributes: Record<string, string> = {};
  for (const match of raw.matchAll(ATTRIBUTE)) {
    const [, name, value] = match;
    if (name !== undefined) attributes[name] = decodeHtmlEntities(value ?? "");
  }
  return attributes;
}
