"use client";

import {
  createElement,
  Fragment,
  useEffect,
  useMemo,
  useRef,
  useState,
  type JSX,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { defineDsElements } from "../define";
import { ISLAND_ATTRIBUTE } from "./serialize";

export interface DsHostProps {
  readonly tag: string;
  readonly attributes: Readonly<Record<string, string>>;
  readonly innerHtml: string;
  /** Ilhas client por slot (ADR-010), já sem o fallback (que está no HTML). */
  readonly islands?: Readonly<Record<string, ReactNode>>;
}

/** Marcador do hydrate do Stencil; some quando o runtime do cliente termina de hidratar o host. */
const HYDRATION_ATTRIBUTE = "s-id";

/**
 * Host do componente no cliente. Servidor e cliente renderizam exatamente o
 * mesmo nó (`dangerouslySetInnerHTML` dos dois lados), então o React não tem
 * mismatch a reportar; depois da hidratação os custom elements são registrados
 * e o runtime do Stencil hidrata o miolo pré-renderizado no lugar (s-id/c-id).
 *
 * Ilhas: cada `<span data-ds-island="nome">` do HTML vira alvo de um portal do
 * React depois que o Stencil hidrata o host (ele recria os nós slotados nesse
 * passo). O fallback estático fica visível até lá e é esvaziado no momento em que
 * o portal monta o React de verdade dentro do slot.
 */
export function DsHost({ tag, attributes, innerHtml, islands }: DsHostProps): JSX.Element {
  const { class: className, ...rest } = attributes;
  const hostRef = useRef<HTMLElement | null>(null);
  const [containers, setContainers] = useState<Readonly<Record<string, Element>>>({});
  const islandNames = islands === undefined ? "" : Object.keys(islands).join(",");
  // O React compara `dangerouslySetInnerHTML` por identidade do objeto: um literal
  // novo a cada render faria o React reescrever o innerHTML (e destruir o DOM que o
  // Stencil hidratou) em qualquer re-render do host — inclusive o que monta as ilhas.
  const html = useMemo(() => ({ __html: innerHtml }), [innerHtml]);

  useEffect(() => {
    defineDsElements();
    const host = hostRef.current;
    if (host === null || islandNames === "") return undefined;

    // O Stencil recria os nós slotados ao hidratar (modo scoped); o portal só
    // pode mirar o placeholder depois disso — quando `s-id` some do host.
    let cancelled = false;
    let observer: MutationObserver | undefined;
    const names = islandNames.split(",");
    const find = (): Record<string, Element> | null => {
      const found: Record<string, Element> = {};
      for (const name of names) {
        const container = host.querySelector(`[${ISLAND_ATTRIBUTE}="${name}"]`);
        if (container === null) return null;
        found[name] = container;
      }
      return found;
    };
    // Os placeholders só estão no lugar definitivo quando o Stencil termina de
    // hidratar (some o `s-id`) e realoca os nós slotados; até lá, observa o host.
    const tryAttach = (): boolean => {
      if (cancelled || host.hasAttribute(HYDRATION_ATTRIBUTE)) return false;
      const found = find();
      if (found === null) return false;
      observer?.disconnect();
      for (const container of Object.values(found)) container.replaceChildren();
      setContainers(found);
      return true;
    };
    void customElements.whenDefined(tag).then(() => {
      if (tryAttach()) return;
      observer = new MutationObserver(() => {
        tryAttach();
      });
      observer.observe(host, { attributes: true, childList: true, subtree: true });
    });
    return () => {
      cancelled = true;
      observer?.disconnect();
    };
  }, [tag, innerHtml, islandNames]);

  const portals =
    islands === undefined
      ? []
      : Object.entries(containers).map(([name, container]) =>
          islands[name] === undefined ? null : createPortal(islands[name], container, name),
        );

  return createElement(
    Fragment,
    null,
    createElement(tag, {
      key: innerHtml,
      ...rest,
      ref: hostRef,
      className,
      suppressHydrationWarning: true,
      dangerouslySetInnerHTML: html,
    }),
    ...portals,
  );
}
