// @vitest-environment jsdom
import { act, StrictMode, createElement, type ReactNode } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { createDsClientComponent } from "./client";

// `act` do React exige a flag global para não avisar em ambiente de teste.
(globalThis as Record<string, unknown>)["IS_REACT_ACT_ENVIRONMENT"] = true;

type Props = { readonly value?: string };
type Events = { readonly onDsPing?: (event: CustomEvent<{ readonly n: number }>) => void };

const DsPing = createDsClientComponent<HTMLElement, Props, Events>({
  tagName: "ds-ping",
  attributes: { value: "value" },
  events: { onDsPing: "dsPing" },
  defineCustomElement: () => {},
  displayName: "DsPing",
});

let root: Root | undefined;
let container: HTMLElement | undefined;

function mount(node: ReactNode): HTMLElement {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  act(() => root?.render(node));
  return container.querySelector("ds-ping") as HTMLElement;
}

function ping(element: HTMLElement, n: number): void {
  act(() => {
    element.dispatchEvent(new CustomEvent("dsPing", { bubbles: true, detail: { n } }));
  });
}

afterEach(() => {
  act(() => root?.unmount());
  container?.remove();
});

describe("eventos do wrapper client", () => {
  it("o handler recebe o CustomEvent", () => {
    const onDsPing = vi.fn();
    const element = mount(createElement(DsPing, { onDsPing }));
    ping(element, 1);
    expect(onDsPing).toHaveBeenCalledTimes(1);
    expect(onDsPing.mock.calls[0]?.[0].detail).toEqual({ n: 1 });
  });

  it("sobrevive à desmontagem simulada do StrictMode (regressão)", () => {
    // Antes: a desmontagem simulada removia o listener e a remontagem, vendo o
    // mesmo handler, não o religava — o evento nunca chegava ao React.
    const onDsPing = vi.fn();
    const element = mount(createElement(StrictMode, null, createElement(DsPing, { onDsPing })));
    ping(element, 2);
    expect(onDsPing).toHaveBeenCalledTimes(1);
  });

  it("troca de handler: o antigo para de receber, o novo recebe", () => {
    const first = vi.fn();
    const second = vi.fn();
    const element = mount(createElement(DsPing, { onDsPing: first }));
    act(() => root?.render(createElement(DsPing, { onDsPing: second })));
    ping(element, 3);
    expect(first).not.toHaveBeenCalled();
    expect(second).toHaveBeenCalledTimes(1);
  });

  it("sem handler não há listener; ao desmontar, o listener sai", () => {
    const onDsPing = vi.fn();
    const element = mount(createElement(DsPing, { onDsPing }));
    act(() => root?.render(createElement(DsPing, {})));
    ping(element, 4);
    expect(onDsPing).not.toHaveBeenCalled();
  });
});
