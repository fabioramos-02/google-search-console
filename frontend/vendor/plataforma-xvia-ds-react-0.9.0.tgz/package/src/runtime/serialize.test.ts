import { createElement, Fragment } from "react";
import { describe, expect, it } from "vitest";
import { dsElementToHtml, islandsToHtml, nodeToHtml } from "./serialize";

const NAV = { tag: "ds-navbar", attributes: { items: "items", label: "label" } };

describe("islandsToHtml", () => {
  it("gera um placeholder por ilha, com o fallback em HTML", async () => {
    const html = await islandsToHtml({
      end: {
        node: createElement("button"),
        fallback: createElement("a", { href: "/entrar" }, "Entrar"),
      },
      tools: { node: null },
    });
    expect(html).toBe(
      '<span slot="end" data-ds-island="end"><a href="/entrar">Entrar</a></span><span slot="tools" data-ds-island="tools"></span>',
    );
  });

  it("sem ilhas não emite nada e rejeita nome inválido", async () => {
    expect(await islandsToHtml(undefined)).toBe("");
    await expect(islandsToHtml({ "bad name": { node: null } })).rejects.toThrow(
      /Nome de ilha inválido/,
    );
  });
});

describe("dsElementToHtml", () => {
  it("anexa as ilhas depois dos filhos, só no componente raiz", async () => {
    const html = await dsElementToHtml(
      NAV,
      { items: "[]", children: createElement("span", { slot: "end" }, "x") },
      { end: { node: null, fallback: "Entrar" } },
    );
    expect(html).toBe(
      '<ds-navbar items="[]"><span slot="end">x</span><span slot="end" data-ds-island="end">Entrar</span></ds-navbar>',
    );
    await expect(dsElementToHtml(NAV, { items: "[]", islands: {} })).rejects.toThrow(
      /mais externo/,
    );
  });
});

describe("nodeToHtml", () => {
  it("serializa fragmentos, texto escapado e atributos", async () => {
    const html = await nodeToHtml(
      createElement(
        Fragment,
        null,
        "a < b",
        createElement("a", { href: "/x", className: "l" }, "y"),
      ),
    );
    expect(html).toBe('a &lt; b<a href="/x" class="l">y</a>');
  });

  it("preserva os atributos camelCase do SVG e passa os demais para kebab-case", async () => {
    const html = await nodeToHtml(
      createElement(
        "svg",
        { viewBox: "0 0 24 24", preserveAspectRatio: "none", strokeWidth: 2 },
        createElement("path", { d: "M0 0", strokeLinecap: "round" }),
      ),
    );
    expect(html).toBe(
      '<svg viewBox="0 0 24 24" preserveAspectRatio="none" stroke-width="2"><path d="M0 0" stroke-linecap="round"></path></svg>',
    );
  });
});
