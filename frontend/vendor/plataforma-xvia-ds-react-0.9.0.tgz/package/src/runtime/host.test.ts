// @vitest-environment jsdom
import { act, createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("../define", () => ({ defineDsElements: () => {} }));

const { DsHost } = await import("./host");

(globalThis as Record<string, unknown>)["IS_REACT_ACT_ENVIRONMENT"] = true;

let root: Root | undefined;
let container: HTMLElement | undefined;

function render(innerHtml: string): HTMLElement {
  if (root === undefined) {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
  }
  act(() =>
    root?.render(
      createElement(DsHost, { tag: "ds-thing", attributes: { "s-id": "1" }, innerHtml }),
    ),
  );
  return container?.querySelector("ds-thing") as HTMLElement;
}

afterEach(() => {
  act(() => root?.unmount());
  container?.remove();
  root = undefined;
});

describe("DsHost", () => {
  it("re-render com o mesmo miolo não toca o DOM que o Stencil hidratou", () => {
    const host = render("<span>a</span>");
    // Simula o Stencil: o miolo hidratado não é o HTML do servidor.
    host.innerHTML = "<button>vivo</button>";
    expect(render("<span>a</span>")).toBe(host);
    expect(host.innerHTML).toBe("<button>vivo</button>");
  });

  it("miolo novo do servidor remonta o host em vez de reescrever por baixo do componente", () => {
    const host = render("<span>a</span>");
    host.innerHTML = "<button>vivo</button>";
    const next = render("<span>b</span>");
    expect(next).not.toBe(host);
    expect(host.isConnected).toBe(false);
    expect(next.innerHTML).toBe("<span>b</span>");
    expect(next.getAttribute("s-id")).toBe("1");
  });
});
