import { describe, expect, it } from "vitest";
import { decodeHtmlEntities, parseAttributes } from "./attributes";

describe("decodeHtmlEntities", () => {
  it("devolve o texto intacto sem entidades", () => {
    expect(decodeHtmlEntities("Início")).toBe("Início");
  });
  it("decodifica as entidades que o hydrate emite em atributos", () => {
    expect(decodeHtmlEntities("Terra &amp; Mar &quot;x&quot;&nbsp;&lt;b&gt;&apos;")).toBe(
      'Terra & Mar "x" <b>\'',
    );
  });
  it("decodifica entidades numéricas decimais e hexadecimais", () => {
    expect(decodeHtmlEntities("&#39;&#x27;&#X41;&#128512;")).toBe("''A😀");
  });
  it("aceita o último code point válido e rejeita o seguinte", () => {
    expect(decodeHtmlEntities("&#1114111;")).toBe("\u{10ffff}");
    expect(decodeHtmlEntities("&#1114112;")).toBe("&#1114112;");
  });
  it("preserva o que não é entidade válida", () => {
    expect(decodeHtmlEntities("&foo; &#xZZ; &#1114112; a & b")).toBe(
      "&foo; &#xZZ; &#1114112; a & b",
    );
  });
});

describe("parseAttributes", () => {
  it("lê atributos com e sem valor e desfaz o escape", () => {
    expect(
      parseAttributes(
        ' items="[{&quot;label&quot;:&quot;A &amp; B&quot;}]" interactive class="x y" s-id="7"',
      ),
    ).toEqual({
      items: '[{"label":"A & B"}]',
      interactive: "",
      class: "x y",
      "s-id": "7",
    });
  });
  it("devolve objeto vazio sem atributos", () => {
    expect(parseAttributes("")).toEqual({});
  });
});
