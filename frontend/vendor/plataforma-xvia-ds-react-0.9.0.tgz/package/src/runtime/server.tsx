import { cache, createElement, Fragment, type JSX, type ReactNode } from "react";
import { renderToString } from "@plataforma-xvia/ds-core/hydrate";
import { DsHost } from "./host";
import { parseAttributes } from "./attributes";
import { claimHydrationId, stabilizeHydrationIds } from "./hydration-ids";
import {
  DS_SERVER,
  dsElementToHtml,
  type DsIsland,
  type DsServerComponentOptions,
  type DsServerMarked,
} from "./serialize";

export type { DsIsland, DsServerComponentOptions } from "./serialize";

/** Props de um componente do DS no servidor: as props do elemento + host + filhos serializáveis. */
export type DsServerProps<P> = { readonly [K in keyof P]?: P[K] | undefined } & {
  readonly children?: ReactNode;
  // `| undefined` explícito: consumidores com `exactOptionalPropertyTypes` passam
  // valores opcionais (ex.: classes de CSS Modules) sem precisar de spreads.
  readonly className?: string | undefined;
  readonly id?: string | undefined;
  readonly slot?: string | undefined;
  /** Atributos extras no host (`data-*`, `aria-*`, `role`). */
  readonly hostAttributes?:
    Readonly<Record<string, string | number | boolean | undefined>> | undefined;
  /** Ilhas client por slot (ADR-010): `{ end: { node: <Sessao />, fallback: <a href="/entrar">Entrar</a> } }`. */
  readonly islands?: Readonly<Record<string, DsIsland>> | undefined;
};

export type DsServerComponent<P> = ((props: DsServerProps<P>) => Promise<JSX.Element>) &
  DsServerMarked;

const OPEN_TAG = /^\s*<([a-z0-9-]+)((?:\s+[^\s=>]+(?:="[^"]*")?)*)\s*>/;

// Ids de hydrate já usados na requisição (`cache` do React memoriza por request em
// RSC). Fora de RSC `cache` não memoriza: cada chamada devolve outro conjunto, e aí os
// ids ficam como vieram do hydrate (únicos, mas não estáveis entre renders).
const takenIds = cache((): Set<number> => new Set());

function stabilize(html: string): string {
  const taken = takenIds();
  if (taken !== takenIds()) return html;
  return stabilizeHydrationIds(html, (preferred) => claimHydrationId(preferred, taken));
}

/**
 * Cria o componente de servidor (RSC) de um custom element do DS.
 * Uma única chamada ao hydrate por raiz: a subárvore (filhos HTML e componentes
 * do DS aninhados) vira uma string, o hydrate renderiza tudo com as props reais,
 * os estilos scoped vão para o `<head>` (`<style precedence>`, deduplicados pelo
 * React 19) e o host chega ao cliente com o miolo pronto.
 */
export function createDsServerComponent<P>(
  options: DsServerComponentOptions,
): DsServerComponent<P> {
  const component = async (props: DsServerProps<P>): Promise<JSX.Element> => {
    if (typeof window !== "undefined") {
      throw new Error(
        `[ds-react/server] <${options.tag}> de @plataforma-xvia/ds-react/server só roda no servidor. No cliente use @plataforma-xvia/ds-react.`,
      );
    }
    const { islands, ...rest } = props as { islands?: Readonly<Record<string, DsIsland>> } & Record<
      string,
      unknown
    >;
    const source = await dsElementToHtml(options, rest, islands);
    const rendered = await renderToString(source, {
      fullDocument: false,
      serializeShadowRoot: "scoped",
      prettyHtml: false,
    });
    if (rendered.html === null)
      throw new Error(`[ds-react/server] O hydrate não devolveu HTML para <${options.tag}>.`);
    const { styles } = rendered;
    const html = stabilize(rendered.html);
    const open = OPEN_TAG.exec(html);
    if (open === null || open[1] !== options.tag) {
      throw new Error(`[ds-react/server] Saída inesperada do hydrate para <${options.tag}>.`);
    }
    const closeIndex = html.lastIndexOf(`</${options.tag}>`);
    const innerHtml = html.slice(open[0].length, closeIndex === -1 ? undefined : closeIndex);
    const attributes = parseAttributes(open[2] ?? "");
    const styleElements = styles
      .filter((style) => typeof style.content === "string" && style.content.length > 0)
      .map((style) => {
        const id = style.id ?? options.tag;
        return createElement("style", {
          key: id,
          href: `stencil-${id}`,
          precedence: "stencil",
          dangerouslySetInnerHTML: { __html: style.content },
        });
      });
    return createElement(
      Fragment,
      null,
      ...styleElements,
      createElement(DsHost, {
        tag: options.tag,
        attributes,
        innerHtml,
        ...(islands === undefined
          ? {}
          : {
              islands: Object.fromEntries(
                Object.entries(islands).map(([name, island]) => [name, island.node]),
              ),
            }),
      }),
    );
  };
  Object.defineProperty(component, DS_SERVER, { value: options, enumerable: false });
  return component as DsServerComponent<P>;
}
