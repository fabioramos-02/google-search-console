const ESCAPES: Readonly<Record<string, string>> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};

export function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (char) => ESCAPES[char] ?? char);
}

export function escapeAttribute(value: string): string {
  return value.replace(/[&"<>]/g, (char) => ESCAPES[char] ?? char);
}

/** `headingLevel` → `heading-level` (mesma regra do Stencil para atributos sem `attribute:`). */
export function toAttributeName(prop: string): string {
  return prop.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}
