import { describe, expect, it } from "vitest";
import { claimHydrationId, stabilizeHydrationIds } from "./hydration-ids";

// Raiz com um componente aninhado (ds-button) e um nó de light DOM realocado por slot.
const html = (root: string, nested: string, node: string): string =>
  `<ds-header s-id="${root}" class="hydrated"><!--r.${root}--><div c-id="${root}.0.0.0">` +
  `<!--s.${root}.1.1.0.brand--><ds-button s-id="${nested}" class="hydrated"><!--r.${nested}-->` +
  `<!--o.0.${node}.c--><a c-id="${nested}.0.0.0"><!--t.0.${node}-->Entrar</a></ds-button>` +
  `<!--t.${root}.2.2.0-->x</div></ds-header>`;

function stabilize(input: string, taken = new Set<number>()): string {
  return stabilizeHydrationIds(input, (preferred) => claimHydrationId(preferred, taken));
}

describe("stabilizeHydrationIds", () => {
  it("o mesmo miolo com números diferentes do hydrate sai idêntico", () => {
    expect(stabilize(html("5108", "5109", "4286"))).toBe(stabilize(html("7", "8", "99")));
  });

  it("raiz, aninhado e nó de slot ganham ids derivados do conteúdo, coerentes entre si", () => {
    const out = stabilize(html("5108", "5109", "4286"));
    const root = /s-id="(\d+)"/.exec(out)?.[1] ?? "";
    const nested = /<ds-button s-id="(\d+)"/.exec(out)?.[1] ?? "";
    expect(Number(root)).toBeGreaterThanOrEqual(1_000_000);
    expect(nested).toBe(String(Number(root) + 1));
    expect(out).toContain(`<!--r.${root}-->`);
    expect(out).toContain(`c-id="${root}.0.0.0"`);
    expect(out).toContain(`<!--s.${root}.1.1.0.brand-->`);
    expect(out).toContain(`<!--t.${root}.2.2.0-->`);
    expect(out).toContain(`<!--r.${nested}-->`);
    expect(out).toContain(`c-id="${nested}.0.0.0"`);
    const node = String(Number(root) * 1_000 + 1);
    expect(out).toContain(`<!--o.0.${node}.c-->`);
    expect(out).toContain(`<!--t.0.${node}-->`);
    expect(out).not.toMatch(/5108|5109|4286/);
  });

  it("miolo diferente dá ids diferentes; raízes idênticas na mesma página não dividem id", () => {
    const taken = new Set<number>();
    const a = stabilize(html("1", "2", "3"), taken);
    const b = stabilize(html("1", "2", "3").replace("Entrar", "Sair"), taken);
    const again = stabilize(html("1", "2", "3"), taken);
    const id = (s: string) => /s-id="(\d+)"/.exec(s)?.[1];
    expect(id(a)).not.toBe(id(b));
    expect(id(again)).not.toBe(id(a));
    expect(again).not.toBe(a);
  });
});

describe("claimHydrationId", () => {
  it("devolve o preferido ou o próximo livre", () => {
    const taken = new Set<number>();
    expect(claimHydrationId(42, taken)).toBe("42");
    expect(claimHydrationId(42, taken)).toBe("43");
    expect(claimHydrationId(43, taken)).toBe("44");
    expect(claimHydrationId(7, taken)).toBe("7");
  });
});
