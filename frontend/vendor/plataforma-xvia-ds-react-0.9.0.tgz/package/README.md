# @plataforma-xvia/ds-react

| Entrada                                    | Conteúdo                                                                                                                                                                           | Origem                                                                                                     |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| `@plataforma-xvia/ds-react` (ou `/client`) | wrappers `'use client'` sobre os custom elements (`@stencil/react-output-target`)                                                                                                  | **gerado** — `src/components.ts`                                                                           |
| `@plataforma-xvia/ds-react/server`         | React Server Components: o hydrate do Stencil renderiza o HTML no servidor com as props e os filhos reais; o cliente recebe o host com o miolo pronto e o runtime hidrata no lugar | **gerado** — `src/server.ts` (de `ds-core/dist/docs.json`) sobre o runtime escrito à mão em `src/runtime/` |

Nunca edite `src/components.ts`, `src/server.ts` nem `src/define.ts`: corrija o componente Stencil, o output target
ou `scripts/generate-server.mjs`. `pnpm check:generated` acusa divergência.

Regras da entrada `/server` (ADR-007): props só string/número/booleano; sem eventos; filhos podem
ser HTML, texto e outros componentes do DS. Para interatividade no React use a entrada client.
